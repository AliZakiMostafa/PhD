# This API to process STEP File data

1. I need to add method to identify which faces are the faces that has all the work 
2. extract data from this face
3. identify outer contour
4. return outer contour elements (lines, arcs, circules)
5. return inner contour elements




# notes
1. slot feature is not applicable yet
2. if part has no inner contours it won't identify the major advanced face



# to do
1. draw part several time each n_group * (l+1.5*t) without fixing any point