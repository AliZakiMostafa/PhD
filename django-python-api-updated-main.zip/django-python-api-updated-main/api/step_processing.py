import os
import numpy as np
import re


def get_file_array(step_file_path):
    with open(step_file_path, "r") as file:
        fileArray = np.array(file.readlines())

    modifiedArray = np.array([], dtype=int)
    for line in fileArray:
        if "#" in line:
            modifiedArray = np.append(modifiedArray, line)

    fileArray = modifiedArray.copy()
    return fileArray


def get_specific_element(fileArray, element):
    elementArray = np.array([], dtype=int)

    for line in fileArray:
        if element in line:
            elementArray = np.append(elementArray, line.strip())
    return elementArray


def get_inside_hashes(line):
    pattern = r"#(\d+)"
    matches = re.findall(pattern, line)
    numbers = [int(match) for match in matches]
    numbers = numbers[1:]
    return numbers


def get_line_by_hash(step_array, hash_num):
    hash_num = "#" + str(hash_num)
    for line in step_array:
        if line.startswith(hash_num):
            return line


def get_element_name(line):
    match = re.search(r"=(\s*)(\w+)", line)
    if match:
        word_after_equal = match.group(2)
        return word_after_equal
    else:
        return False


def get_circle_radius(line):
    match = re.search(r"\(([^,]+),\s*([^,]+),\s*([^,]+)\)", line)
    if match:
        third_element = match.group(3)
        return round(float(third_element), 2)
    else:
        return False


def get_specific_element(fileArray, element):
    elementArray = np.array([], dtype=int)

    for line in fileArray:
        if element in line:
            elementArray = np.append(elementArray, line.strip())
    return elementArray


def data_extract(fileArray, line, output_data):
    hashes = get_inside_hashes(line)
    if hashes:
        for hash1 in hashes:
            new_line = fileArray[hash1 - 1]
            output_data.append(new_line)
            data_extract(fileArray, new_line, output_data)
    return output_data


def get_extracted_data(fileArray, required_array):
    output_data = []
    for line in required_array:
        output_data.append(line)
        output_data = data_extract(fileArray, line, output_data)

    return output_data


def get_numbers_from_string(string):
    start = string.find("(")
    end = string.find(")")
    parenthesis = string[start : end + 1]
    return parenthesis


def extract_numbers_from_string(string):
    new_string = get_numbers_from_string(string)[1:]
    new_string = get_numbers_from_string(new_string)
    numbers = new_string[1:-1].split(",")
    numbers = [float(num) for num in numbers]
    return [round(num) for num in numbers]


def get_circle_center_point(step_array, circle):
    circle_data = get_extracted_data(step_array, [circle])
    center_point_string = get_specific_element(circle_data, "CARTESIAN_POINT")
    points = extract_numbers_from_string(center_point_string[0])
    return points


def identify_major_face(step_array):
    advanced_face_array = get_specific_element(step_array, "ADVANCED_FACE")
    major_face = None
    max_hashes = 0

    for face in advanced_face_array:
        numbers = get_inside_hashes(face)
        if len(numbers) > max_hashes and "T." in face:
            max_hashes = len(numbers)
            major_face = face

    return major_face


def get_thickness_from_advanced_face(step_array):
    advanced_face_array = get_specific_element(step_array, "ADVANCED_FACE")

    # Initialize a dictionary to store the face and its corresponding number of hashes
    face_hash_counts = {}

    for face in advanced_face_array:
        numbers = get_inside_hashes(face)
        face_hash_counts[face] = len(numbers)

    # Sort the faces based on the number of hashes in descending order
    sorted_faces = sorted(face_hash_counts, key=face_hash_counts.get, reverse=True)

    # Get the two maximum faces
    max_faces = sorted_faces[:2]

    return max_faces



def line_first(item):
    if 'LINE' in item:
        return 0
    else:
        return 1



def extract_outer_face_data(step_array, face):
    print(face)
    output_array = get_extracted_data(step_array, [face])
    outer_boundary = get_specific_element(output_array, "FACE_OUTER_BOUND")
    outer_boundary_data = get_extracted_data(step_array, outer_boundary)
    edge_curve_outer_bond_data = get_specific_element(outer_boundary_data, "EDGE_CURVE")
    face_lst = []
    for edge in edge_curve_outer_bond_data:
        edge_data = get_inside_hashes(edge)
        edge_lst = []
        for e in edge_data:
            e_line = get_line_by_hash(step_array, e)
            element_name = get_element_name(e_line)
            edge_lst.append(element_name)
            if element_name == "LINE":
                pass
            if element_name == "CIRCLE":
                # get center point and radius
                center_point = get_circle_center_point(step_array, e_line)
                edge_lst += center_point
                radius = get_circle_radius(e_line)
                edge_lst.append(radius)

            if element_name == "VERTEX_POINT":
                # get cartisean in this element
                # store it in the lst
                element_data = get_extracted_data(step_array, [e_line])
                # print(element_data)
                cart_line_array = get_specific_element(element_data, "CARTESIAN_POINT ")
                for cart in cart_line_array:
                    points = extract_numbers_from_string(cart)
                    edge_lst += points

        face_lst.append(edge_lst)



    sorted_data = sorted(face_lst, key=line_first)

    return sorted_data


def extract_inner_face_data(step_array, face):
    print(face)
    output_array = get_extracted_data(step_array, [face])
    outer_boundary = get_specific_element(output_array, "FACE_BOUND")
    outer_boundary_data = get_extracted_data(step_array, outer_boundary)
    edge_curve_outer_bond_data = get_specific_element(outer_boundary_data, "EDGE_CURVE")
    print(outer_boundary)
    face_lst = []
    for edge in edge_curve_outer_bond_data:
        edge_data = get_inside_hashes(edge)
        edge_lst = []
        for e in edge_data:
            e_line = get_line_by_hash(step_array, e)
            element_name = get_element_name(e_line)
            edge_lst.append(element_name)
            if element_name == "LINE":
                pass
            if element_name == "CIRCLE":
                # get center point and radius
                center_point = get_circle_center_point(step_array, e_line)
                edge_lst += center_point
                radius = get_circle_radius(e_line)
                edge_lst.append(radius)

            if element_name == "VERTEX_POINT":
                # get cartisean in this element
                # store it in the lst
                element_data = get_extracted_data(step_array, [e_line])
                # print(element_data)
                cart_line_array = get_specific_element(element_data, "CARTESIAN_POINT")
                for cart in cart_line_array:
                    points = extract_numbers_from_string(cart)
                    edge_lst += points

        face_lst.append(edge_lst)

    return face_lst


# function to return data for inner contour
def get_inner_contours_data(step_array, major_face):
    inner_boundaries = get_specific_element(step_array, "FACE_BOUND")
    contours_data = []
    for contour in inner_boundaries:
        contours_data.append(extract_inner_face_data(step_array, contour))

    return contours_data

# processing punches

def process_punch_data(inner_contours):
    if len(inner_contours) == 0:
        return []
    punches_contour = []    
    punch_length = 50
    cap1 = 3
    cap2 = 2
    clearence=7
    cap0_thickness = 0.1*punch_length
    cap1_thickness =  0.4*punch_length
    cap2_thickness = 0.5*punch_length
    for i,contour in enumerate(inner_contours):
        if len(contour)>0:
            print(f"len:{len(contour)},contour:{contour}")
            for j,entity in enumerate(contour):
                if entity[8] == 'CIRCLE':
                    center_point = (entity[9],entity[10]+clearence,entity[11])
                    radius = entity[12]
                    cap0 = radius + cap1 + cap2
                    #start creating punch entities
                    entity1 = ['VERTEX_POINT', center_point[0], center_point[1], center_point[2], 'VERTEX_POINT', center_point[0], center_point[1]+punch_length, center_point[2], 'LINE',radius]
                    entity2 = ['VERTEX_POINT', center_point[0], center_point[1]+punch_length, center_point[2], 'VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length, 0, 'LINE']
                    entity3 = ['VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length, center_point[2], 'VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length-cap0_thickness, 0, 'LINE']
                    entity4 = ['VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length-cap0_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness, 0, 'LINE']
                    entity5 = ['VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness-cap1_thickness, 0, 'LINE']
                    entity6 = ['VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness-cap1_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness, 0, 'LINE']
                    entity7 = ['VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness-cap2_thickness, 0, 'LINE']
                    entity8 = ['VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness-cap2_thickness, center_point[2], 'VERTEX_POINT', center_point[0], center_point[1], 0, 'LINE']

                    punches_contour.append([
                        entity1,entity2,entity3,entity4,entity5,entity6,entity7,entity8
                    ])
                
    print(f"p contours:{punches_contour}")
    return punches_contour

    
def get_cirle_center(inner_contours):
    center_points=[]
    if len(inner_contours) == 0:
        return []
    for i,contour in enumerate(inner_contours):
        if len(contour)>0:
            print(f"len:{len(contour)},contour:{contour}")
            for j,entity in enumerate(contour):
                if entity[8] == 'CIRCLE':
                    center_point = (entity[9],entity[10],entity[11])
                    center_points.append([entity[9],entity[10],entity[11]])
    print(f"center points:{center_points}")
    return center_points


def process_die_data(inner_contours):
    if len(inner_contours) == 0:
        return []
    punches_contour = []    
    die_length= 15
    clearance = 0.25
    offset= 1
    die_base = 5
    for i,contour in enumerate(inner_contours):
        if len(contour)>0:
            print(f"len:{len(contour)},contour:{contour}")
            for j,entity in enumerate(contour):
                if entity[8] == 'CIRCLE':
                    center_point = (entity[9],entity[10],entity[11])
                    radius = entity[12]
                    #start creating punch entities
                    entity1 = ['VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset, center_point[2], 'VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset-die_base, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity2 = ['VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset-die_base, center_point[2], 'VERTEX_POINT',center_point[0]+radius+1+clearance, center_point[1]-offset-die_base-die_length, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity3 = ['VERTEX_POINT', center_point[0]+radius+1+clearance, center_point[1]-offset-die_base-die_length, center_point[2], 'VERTEX_POINT', center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity4 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length, center_point[2], 'VERTEX_POINT',  center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length+4.1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity5 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length+4.1, center_point[2], 'VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity6 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity7 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'VERTEX_POINT',center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base+4.1+1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity8 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base+4.1+1, center_point[2], 'VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]

                    punches_contour.append([
                        entity1,entity2,entity3,entity4,entity5,entity6,entity7,entity8
                    ])
                
    print(f"die contours:{punches_contour}")
    return punches_contour



