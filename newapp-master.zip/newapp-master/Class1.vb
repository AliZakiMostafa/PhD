﻿Imports System.Net.Http
Imports System.Runtime.InteropServices.ComTypes
Imports System.Threading
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq




Public Class getFromApi
    Public client As New HttpClient()
    Public apiUrl As String = "http://127.0.0.1:8000/"

    Public fullUrl As String
    Public outerContourData As List(Of List(Of Object))
    Public innerContoursData As JArray
    Public dataDict As Dictionary(Of String, Object)
    Public innerContoursList As List(Of Object)


    Public Sub StartServer()
        Dim batchFilePath As String = "C:\Users\user\source\repos\django-python-api\runserver.bat"

        ' Open the batch file
        Process.Start(batchFilePath)
        Thread.Sleep(4000)


    End Sub

    Public Sub GetStepFile(ByVal stepfilepath As String)
        ' Create the full URL by combining the base URL and endpoint
        fullUrl = "file-path\?path=" & stepfilepath
        Dim response As String = GetData(fullUrl)
        ' Check if the request was successful (status code 200)
        ' Read the response content as a string
        dataDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response)
        outerContourData = dataDict("outer contour data").ToObject(Of List(Of List(Of Object)))()
        innerContoursData = dataDict("inner_contours_data")
        ' Convert the JArray to a list of objects (or any other desired data structure)
        innerContoursList = innerContoursData.ToObject(Of List(Of Object))()
    End Sub
    Public Function GetData(ByVal apiEndpoint As String)

        ' Create the full URL by combining the base URL and endpoint
        Dim fullUrl As String = apiUrl & apiEndpoint

        ' Send a GET request to the API
        Dim response As HttpResponseMessage = client.GetAsync(fullUrl).Result
        Dim responseContent As String
        ' Check if the request was successful (status code 200)
        If response.IsSuccessStatusCode Then
            ' Read the response content as a string
            responseContent = response.Content.ReadAsStringAsync().Result

            ' Print the response content
            Console.WriteLine(responseContent)
        Else
            ' Print the error status code
            responseContent = 0

            Console.WriteLine("Error: " & response.StatusCode)
        End If
        Return responseContent
    End Function

    Public Function GetOuterContour()

        Return outerContourData
    End Function
    Public Function GetInnerContour()

        Return innerContoursData
    End Function

    Public Function GetPunchContours()
        ' send request to the end point to get punch data
        Dim response As String = GetData("punch")
        Dim punchDict As Dictionary(Of String, Object)
        Console.WriteLine("resonse: " & response)
        punchDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response)
        Dim punchContoursData As JArray
        punchContoursData = punchDict("Punches contours")
        Return punchContoursData

    End Function
    Public Function GetRectPunchContours()
        Dim response As String = GetData("rect_punch")
        Dim punchDict As Dictionary(Of String, Object)
        Console.WriteLine("resonse: " & response)
        punchDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response)
        Dim punchContoursData As JArray
        punchContoursData = punchDict("Punches contours")
        Return punchContoursData

    End Function
    Public Function GetExtPunchContours()
        ' send request to the end point to get punch data
        Dim response As String = GetData("expunch")
        Dim punchDict As Dictionary(Of String, Object)
        Console.WriteLine("resonse: " & response)
        punchDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response)
        Dim punchContoursData As JArray
        punchContoursData = punchDict("Punches contours")
        Return punchContoursData

    End Function


    Public Function GetDieContours()
        ' send request to the end point to get punch data
        Dim response As String = GetData("die")
        Dim punchDict As Dictionary(Of String, Object)
        Console.WriteLine("resonse: " & response)
        punchDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response)
        Dim punchContoursData As JArray
        punchContoursData = punchDict("Dies contours")
        Return punchContoursData

    End Function

    Public Function GetIrregularDieContours()
        ' send request to the end point to get punch data
        Dim response As String = GetData("irdie")
        Dim dieDict As Dictionary(Of String, Object)
        Console.WriteLine("resonse: " & response)
        dieDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response)
        Dim dieContoursData As JArray
        dieContoursData = dieDict("Dies contours")
        Return dieContoursData

    End Function

    Public Function GetCenterPoint()
        ' send request to the end point to get punch data
        Dim response As String = GetData("centerpoint")
        Dim punchDict As Dictionary(Of String, Object)
        Console.WriteLine("resonse: " & response)
        punchDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(response)
        Dim punchContoursData As JArray
        punchContoursData = punchDict("centerpoint")
        Return punchContoursData

    End Function

End Class
