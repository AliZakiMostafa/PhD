﻿
Imports SolidWorks.Interop.swconst
Imports SolidWorks.Interop.sldworks
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System
Imports System.Net.Http
Imports Newtonsoft.Json
Imports System.IO

Imports System.Diagnostics
Imports System.Threading
Imports Newtonsoft.Json.Linq

Public Class Form1
    Public innerContoursData As JArray
    Public outerContourData As List(Of List(Of Object))
    Public PunchContoursData As JArray
    Public centerpoint As JArray
    Public IrDieData As JArray

    Dim stepFilePath As String
    Dim partFilePath As String
    Dim folder As String
    Dim punchLst As String() = {} ' Empty string array for circular punches
    Dim rectpunchLst As String() = {} 'Emty string array for rect punches
    Dim extpunchLst As String() = {} 'Emty string array for extruded punches
    Public api As New getFromApi()



    Public Sub ResetVariables()
        ' Reset innerContoursData
        innerContoursData = New JArray()

        ' Reset outerContourData
        outerContourData = New List(Of List(Of Object))()

        ' Reset PunchContoursData
        PunchContoursData = New JArray()

        ' Reset centerpoint
        centerpoint = New JArray()

        ' Reset other variables
        stepFilePath = ""
        partFilePath = ""
        folder = ""
        punchLst = New String() {}
        rectpunchLst = New String() {}
        extpunchLst = New String() {}
        api = New getFromApi()
    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True

        ' creat new part 

        Part = App.NewPart()


        If Part IsNot Nothing Then

            'select fornt plane 
            boolstatus = Part.Extension.SelectByID2("Top plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            'insert sketch
            Part.SketchManager.InsertSketch(True)


            '' start from here 

            Part.SketchManager.CreateLine(0, 0, 0, 20 / 1000, 0, 0)
            Part.SketchManager.CreateArc(20 / 1000, -5 / 1000, 0, 20 / 1000, 0, 0, 25 / 1000, -5 / 1000, 0, 0)
            Part.SketchManager.CreateLine(25 / 1000, -5 / 1000, 0, 25 / 1000, -55 / 1000, 0)
            Part.SketchManager.CreateArc(20 / 1000, -55 / 1000, 0, 25 / 1000, -55 / 1000, 0, 20 / 1000, -60 / 1000, 0, 0)
            Part.SketchManager.CreateLine(20 / 1000, -60 / 1000, 0, 0, -60 / 1000, 0)
            Part.SketchManager.CreateLine(0, -60 / 1000, 0, 0, 0, 0)



            'create extrude

            Part.FeatureManager.FeatureExtrusion2(True, False, False, 0, 0, 0.01, 0.01, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)

            'sketch on upper face 
            boolstatus = Part.Extension.SelectByRay(0.00630879413512275, 0.00999999999999091, 0.0160052703436122, -0.532443489318979, -0.505863873407781, 0.67867935894847, 0.000350805070229531, 2, False, 0, 0)
            Part.SketchManager.InsertSketch(True)
            Part.SketchManager.CreateLine(0, -5 / 1000, 0, 20 / 1000, -5 / 1000, 0)
            Part.SketchManager.CreateLine(20 / 1000, -5 / 1000, 0, 20 / 1000, -55 / 1000, 0)
            Part.SketchManager.CreateLine(20 / 1000, -55 / 1000, 0, 0, -55 / 1000, 0)
            Part.SketchManager.CreateLine(0, -55 / 1000, 0, 0, -5 / 1000, 0)

            'Extrude  

            Part.FeatureManager.FeatureExtrusion2(True, False, False, 0, 0, 0.147, 0.01, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)




            'select fornt plane 
            boolstatus = Part.Extension.SelectByID2("Top plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            'insert sketch
            Part.SketchManager.InsertSketch(True)
            Part.SketchManager.CreateCircleByRadius(0, 0, 0, 5 / 1000)
            boolstatus = Part.Extension.SelectByRay(25 / 1000, 10 / 1000, 5 / 1000, 0, 0, 1, 0.0001, 1, False, 0, 0)
            boolstatus = Part.Extension.SelectByRay(0.0243937493431901, 0.0000250723436465705, 0.00255855917197323, -0.163666941578665, 0.568144480797094, 0.806489293899235, 0.000435132448285477, 1, False, 0, 0)
            boolstatus = Part.SketchManager.SketchUseEdge3(False, False)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByRay(0, 0, 0, 0, -1, 0, 0, 1, False, 0, 0)
            boolstatus = Part.SketchManager.SketchUseEdge3(False, False)
            boolstatus = Part.Extension.SelectByRay(20 / 1000, 10 / 1000, 55 / 1000, 0, -1, 0, 0, 1, False, 0, 0)
            boolstatus = Part.SketchManager.SketchUseEdge3(False, False)
            boolstatus = Part.Extension.SelectByRay(0, 0.175, 0.005, 0, -1, 0, 0.0003, 1, False, 0, 0)
            'boolstatus = Part.SketchManager.SketchUseEdge3(False, False)
        End If

        ' Add code to create the part geometry here

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True
        Part = App.NewPart()

        If Part IsNot Nothing Then

            'select fornt plane 
            boolstatus = Part.Extension.SelectByID2("Top plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            'insert sketch
            Part.SketchManager.InsertSketch(True)


            '' start from here 
            Part.SketchManager.CreateCircleByRadius(0, 0, 0, 5 / 1000)
            ' Part.SketchManager.CreateLine(50 / 1000, 10 / 1000, 50 / 1000)
            ' creat new part

        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True

        ' creat new part 

        Part = App.NewPart()


        If Part IsNot Nothing Then

            'create new 3 point plane 

            Part.SketchManager.Insert3DSketch(True)
            Part.SketchManager.CreatePoint(-50 / 1000, 10 / 1000, 50 / 1000)
            Part.SketchManager.CreatePoint(50 / 1000, 10 / 1000, 50 / 1000)
            Part.SketchManager.CreatePoint(50 / 1000, 10 / 1000, -50 / 1000)
            Part.ClearSelection2(True)
            Part.SketchManager.InsertSketch(True)
            Part.ClearSelection2(True)


            Part.Extension.SelectByID2("", "SketchPoint", -50 / 1000, 10 / 1000, 50 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 50 / 1000, 10 / 1000, 50 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 50 / 1000, 10 / 1000, -50 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0.1, 4, 0, 4, 0)

            Part.Extension.SelectByID2("plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)



        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True

        ' creat new part 

        Part = App.NewPart()


        If Part IsNot Nothing Then

            'create new 3 point plane 

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreateLine(50 / 1000, 10 / 1000, 50 / 1000, 50 / 1000, 10 / 1000, -50 / 1000)
            Part.SketchManager.CreateLine(50 / 1000, 10 / 1000, -50 / 1000, -50 / 1000, 10 / 1000, -50 / 1000)
            Part.SketchManager.CreateLine(-50 / 1000, 10 / 1000, -50 / 1000, -50 / 1000, 10 / 1000, 50 / 1000)
            Part.SketchManager.CreateLine(-50 / 1000, 10 / 1000, 50 / 1000, 50 / 1000, 10 / 1000, 50 / 1000)
            Part.ClearSelection2(True)
            Part.SketchManager.InsertSketch(True)
            Part.ClearSelection2(True)
            Part.Extension.SelectByID2("", "SketchPoint", 50 / 1000, 10 / 1000, -50 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("Line4@3DSketch1", "SKETCHSEGMENT", 50 / 1000, 10 / 1000, 50 / 1000, True, 0, Nothing, 0)
            'Part.SketchManager.Insert3DSketch(True)

            ' Part.SketchManager.CreateLine(50 / 1000, 0, 50 / 1000, 50 / 1000, 0, -50 / 1000)
            'Part.SketchManager.CreateLine(-50 / 1000, 0 / 1000, 50 / 1000, 50 / 1000, 0, 50 / 1000)
            'Part.SketchManager.CreateLine(-50 / 1000, 0, -50 / 1000, -50 / 1000, 0, 50 / 1000)
            'Part.SketchManager.CreateLine(50 / 1000, 0, -50 / 1000, -50 / 1000, 0, -50 / 1000)
            'Part.SketchManager.CreateCircleByRadius(0, 0, 0, 10 / 1000)
            'Part.ClearSelection2(True)
            'Part.SketchManager.InsertSketch(True)
            'Part.ClearSelection2(True)

        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean
        Dim swAssembly As AssemblyDoc
        Dim swInsertedComponent As Component2
        Dim swSelMgr As SelectionMgr
        Dim objFSO As Object
        Dim objFile As Object
        Dim compName As String
        Dim splits As Object
        Dim status As Integer


        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True

        '*********************************************************************

        ' creat new part 

        Part = App.NewPart()

        '*********************************************************************

        If Part IsNot Nothing Then

            'create FACE_OUTER_BOUND plan

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreateLine(-50 / 1000, 10 / 1000, -50 / 1000, -50 / 1000, 10 / 1000, 40 / 1000)
            Part.SketchManager.CreateLine(-50 / 1000, 10 / 1000, 40 / 1000, -40 / 1000, 10 / 1000, 50 / 1000)
            Part.ClearSelection2(True)
            Part.SketchManager.InsertSketch(True)
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("", "SketchPoint", -50 / 1000, 10 / 1000, -50 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -50 / 1000, 10 / 1000, 40 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -40 / 1000, 10 / 1000, 50 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)

            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B plane")
            Part.ClearSelection2(True)

            'hide sketch 
            Part.Extension.SelectByID2("3DSketch1", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.BlankSketch()

            '*********************************************************************

            'insert 3d sketch for outer boundry


            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreateLine(-50 / 1000, 10 / 1000, -50 / 1000, -50 / 1000, 10 / 1000, 40 / 1000)
            Part.SketchManager.CreateLine(-50 / 1000, 10 / 1000, 40 / 1000, -40 / 1000, 10 / 1000, 50 / 1000)
            Part.SketchManager.CreateLine(-40 / 1000, 10 / 1000, 50 / 1000, 50 / 1000, 10 / 1000, 50 / 1000)
            Part.SketchManager.CreateLine(50 / 1000, 10 / 1000, 50 / 1000, 50 / 1000, 10 / 1000, -40 / 1000)
            Part.SketchManager.CreateLine(40 / 1000, 10 / 1000, -50 / 1000, -50 / 1000, 10 / 1000, -50 / 1000)
            'Part.SketchManager.CreateArc(40 / 1000, 10 / 1000, -40 / 1000, 50 / 1000, 10 / 1000, -40 / 1000, 40 / 1000, 10 / 1000, -50 / 1000, 1)
            Part.SketchManager.CreateTangentArc(50 / 1000, 10 / 1000, -40 / 1000, 40 / 1000, 10 / 1000, -50 / 1000, 1)

            ' Rename for outer bound sketch 

            Part.Extension.SelectByID2("3DSketch2", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B Sketch")

            'extrude for outer bound 
            Part.Extension.SelectByID2("O.B Sketch", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, 0.006, 0.006, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)
            Part.SelectionManager.EnableContourSelection = False

            '*********************************************************************

            'create internal bound 

            'create FACE_BOUND 1 

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreateLine(30 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, -5 / 1000)
            Part.SketchManager.CreateLine(20 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, 5 / 1000)
            Part.SketchManager.CreateLine(20 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, 5 / 1000)
            Part.SketchManager.CreateLine(30 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, -5 / 1000)

            'create FACE_BOUND 2 

            Part.SketchManager.CreateLine(-31.57 / 1000, 10 / 1000, 5.84 / 1000, -23.22 / 1000, 10 / 1000, 8.61 / 1000)
            Part.SketchManager.CreateLine(-33.35 / 1000, 10 / 1000, -2.77 / 1000, -31.57 / 1000, 10 / 1000, 5.84 / 1000)
            Part.SketchManager.CreateLine(-26.77 / 1000, 10 / 1000, -8.61 / 1000, -33.35 / 1000, 10 / 1000, -2.77 / 1000)
            Part.SketchManager.CreateLine(-18.43 / 1000, 10 / 1000, -5.84 / 1000, -26.77 / 1000, 10 / 1000, -8.61 / 1000)
            Part.SketchManager.CreateLine(-16.65 / 1000, 10 / 1000, 2.76 / 1000, -18.43 / 1000, 10 / 1000, -5.84 / 1000)
            Part.SketchManager.CreateLine(-23.22 / 1000, 10 / 1000, 8.61 / 1000, -16.65 / 1000, 10 / 1000, 2.76 / 1000)

            'rename inner bound 3d sketch 

            Part.Extension.SelectByID2("3DSketch3", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "I.B Sketch")

            'extrude cut for inner bound in 3d sketch 
            Part.Extension.SelectByID2("I.B Sketch", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            Part.FeatureManager.FeatureCut4(True, False, True, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)

            '*********************************************************************


            'create FACE_BOUND 3

            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SketchManager.InsertSketch(True)
            Part.SketchManager.CreateCircleByRadius(35 / 1000, 35 / 1000, 0, 4 / 1000)
            Part.SketchManager.CreateCircleByRadius(-35 / 1000, -35 / 1000, 0, 4 / 1000)
            Part.SketchManager.CreateCircleByRadius(0, 0, 0, 10 / 1000)
            Part.SketchManager.CreateCircleByRadius(35 / 1000, -35 / 1000, 0, 4 / 1000)
            Part.SketchManager.CreateCircleByRadius(-35 / 1000, 35 / 1000, 0, 4 / 1000)

            'Rename for sketch 
            Part.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "Holes Sketch")

            'extrude cut holes inner bound 


            Part.FeatureManager.FeatureCut4(True, False, False, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)

            '*********************************************************************

            ' iso metric view and save 

            Part.ShowNamedView2("*Isometric", 7)
            Part.ViewZoomtofit2()

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\part 5.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document
            App.CloseDoc("part 5")

            '*********************************************************************

            'creat new part for punch no. 1
            Dim x1 As String
            x1 = 10

            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(-35 / 1000, x1 / 1000, 31 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, x1 / 1000, 39 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, 0 / 1000, 31 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, x1 / 1000, 31 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, x1 / 1000, 39 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 0 / 1000, 31 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 1 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 1 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateLine(-35 / 1000, 11 / 1000, 0, -35 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(-35 / 1000, 61 / 1000, 0, -26 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(-26 / 1000, 61 / 1000, 0, -26 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(-26 / 1000, 56 / 1000, 0, -29 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(-29 / 1000, 56 / 1000, 0, -29 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(-29 / 1000, 36 / 1000, 0, -31 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(-31 / 1000, 36 / 1000, 0, -31 / 1000, 11 / 1000, 0)
            Part.SketchManager.CreateLine(-31 / 1000, 11 / 1000, 0, -35 / 1000, 11 / 1000, 0)


            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)
            Dim myFeature As Object
            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False



            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 1.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round punch 1")

            '*****************************************************************************

            'creat new part for insert no. 1


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(-35 / 1000, x1 / 1000, 31 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, x1 / 1000, 39 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, 0 / 1000, 31 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, x1 / 1000, 31 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, x1 / 1000, 39 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 0 / 1000, 31 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "insert 1 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("insert 1 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateCenterLine(-35 / 1000, 10 / 1000, 0 / 1000, -35 / 1000, 0 / 1000, 0 / 1000)
            Part.SketchManager.CreateLine(-30.75 / 1000, 3 / 1000, 0, -30.75 / 1000, -2 / 1000, 0)
            Part.SketchManager.CreateLine(-30.75 / 1000, -2 / 1000, 0, -29.7 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(-29.7 / 1000, -32 / 1000, 0, -20.75 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(-20.75 / 1000, -32 / 1000, 0, -20.75 / 1000, -25 / 1000, 0)
            Part.SketchManager.CreateLine(-20.75 / 1000, -25 / 1000, 0, -21.75 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(-21.75 / 1000, -24 / 1000, 0, -25.75 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(-25.75 / 1000, -24 / 1000, 0, -25.75 / 1000, 3 / 1000, 0)
            Part.SketchManager.CreateLine(-25.75 / 1000, 3 / 1000, 0, -30.75 / 1000, 3 / 1000, 0)


            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 1.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round insert 1")

            '*****************************************************************************


            'creat new part for punch no.2 


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, 31 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, 39 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 0 / 1000, 31 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, 31 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, 39 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 0 / 1000, 31 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 2 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 2 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateLine(35 / 1000, 11 / 1000, 0, 35 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(35 / 1000, 61 / 1000, 0, 26 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(26 / 1000, 61 / 1000, 0, 26 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(26 / 1000, 56 / 1000, 0, 29 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(29 / 1000, 56 / 1000, 0, 29 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(29 / 1000, 36 / 1000, 0, 31 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(31 / 1000, 36 / 1000, 0, 31 / 1000, 11 / 1000, 0)
            Part.SketchManager.CreateLine(31 / 1000, 11 / 1000, 0, 35 / 1000, 11 / 1000, 0)


            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 2.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round punch 2")

            '*****************************************************************************

            'creat new part for insert no. 2


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, 31 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, 39 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 0 / 1000, 31 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, 31 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, 39 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 0 / 1000, 31 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "insert 2 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("insert 2 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateCenterLine(35 / 1000, 10 / 1000, 0 / 1000, 35 / 1000, 0 / 1000, 0 / 1000)
            Part.SketchManager.CreateLine(39.25 / 1000, 3 / 1000, 0, 39.25 / 1000, -2 / 1000, 0)
            Part.SketchManager.CreateLine(39.25 / 1000, -2 / 1000, 0, 40.3 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(40.3 / 1000, -32 / 1000, 0, 49.25 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(49.25 / 1000, -32 / 1000, 0, 49.25 / 1000, -25 / 1000, 0)
            Part.SketchManager.CreateLine(49.25 / 1000, -25 / 1000, 0, 48.25 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(48.25 / 1000, -24 / 1000, 0, 44.25 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(44.25 / 1000, -24 / 1000, 0, 44.25 / 1000, 3 / 1000, 0)
            Part.SketchManager.CreateLine(44.25 / 1000, 3 / 1000, 0, 39.25 / 1000, 3 / 1000, 0)


            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 2.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round insert 2")


            '*****************************************************************************

            'creat new part for punch no.3 


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, -39 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, -30 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 0 / 1000, -30 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, -39 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, -30 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 0 / 1000, -30 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 3 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 3 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateLine(-35 / 1000, 11 / 1000, 0, -35 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(-35 / 1000, 61 / 1000, 0, -26 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(-26 / 1000, 61 / 1000, 0, -26 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(-26 / 1000, 56 / 1000, 0, -29 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(-29 / 1000, 56 / 1000, 0, -29 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(-29 / 1000, 36 / 1000, 0, -31 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(-31 / 1000, 36 / 1000, 0, -31 / 1000, 11 / 1000, 0)
            Part.SketchManager.CreateLine(-31 / 1000, 11 / 1000, 0, -35 / 1000, 11 / 1000, 0)


            Part.ViewZoomtofit2()


            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 3.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round punch 3")


            '*****************************************************************************

            'creat new part for insert no. 3


            Part = App.NewPart()


            Part.SketchManager.Insert3DSketch(True)


            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, -39 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 10 / 1000, -30 / 1000)
            Part.SketchManager.CreatePoint(35 / 1000, 0 / 1000, -30 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, -39 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 10 / 1000, -30 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 35 / 1000, 0 / 1000, -30 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)



            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "insert 3 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("insert 3 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateCenterLine(-35 / 1000, 10 / 1000, 0 / 1000, -35 / 1000, 0 / 1000, 0 / 1000)
            Part.SketchManager.CreateLine(-30.75 / 1000, 3 / 1000, 0, -30.75 / 1000, -2 / 1000, 0)
            Part.SketchManager.CreateLine(-30.75 / 1000, -2 / 1000, 0, -29.7 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(-29.7 / 1000, -32 / 1000, 0, -20.75 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(-20.75 / 1000, -32 / 1000, 0, -20.75 / 1000, -25 / 1000, 0)
            Part.SketchManager.CreateLine(-20.75 / 1000, -25 / 1000, 0, -21.75 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(-21.75 / 1000, -24 / 1000, 0, -25.75 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(-25.75 / 1000, -24 / 1000, 0, -25.75 / 1000, 3 / 1000, 0)
            Part.SketchManager.CreateLine(-25.75 / 1000, 3 / 1000, 0, -30.75 / 1000, 3 / 1000, 0)


            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 3.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round insert 3")

            '*****************************************************************************

            'creat new part for punch no.4   


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(-35 / 1000, 10 / 1000, -39 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, 10 / 1000, -35 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, 0 / 1000, -31 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 10 / 1000, -39 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 10 / 1000, -35 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 0 / 1000, -31 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 4 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 4 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateLine(35 / 1000, 11 / 1000, 0, 35 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(35 / 1000, 61 / 1000, 0, 26 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(26 / 1000, 61 / 1000, 0, 26 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(26 / 1000, 56 / 1000, 0, 29 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(29 / 1000, 56 / 1000, 0, 29 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(29 / 1000, 36 / 1000, 0, 31 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(31 / 1000, 36 / 1000, 0, 31 / 1000, 11 / 1000, 0)
            Part.SketchManager.CreateLine(31 / 1000, 11 / 1000, 0, 35 / 1000, 11 / 1000, 0)


            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 4.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round punch 4")

            '*****************************************************************************

            'creat new part for insert no. 4


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(-35 / 1000, 10 / 1000, -39 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, 10 / 1000, -35 / 1000)
            Part.SketchManager.CreatePoint(-35 / 1000, 0 / 1000, -31 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 10 / 1000, -39 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 10 / 1000, -35 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", -35 / 1000, 0 / 1000, -31 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "insert 4 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("insert 4 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateCenterLine(35 / 1000, 10 / 1000, 0 / 1000, 35 / 1000, 0 / 1000, 0 / 1000)
            Part.SketchManager.CreateLine(39.25 / 1000, 3 / 1000, 0, 39.25 / 1000, -2 / 1000, 0)
            Part.SketchManager.CreateLine(39.25 / 1000, -2 / 1000, 0, 40.3 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(40.3 / 1000, -32 / 1000, 0, 49.25 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(49.25 / 1000, -32 / 1000, 0, 49.25 / 1000, -25 / 1000, 0)
            Part.SketchManager.CreateLine(49.25 / 1000, -25 / 1000, 0, 48.25 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(48.25 / 1000, -24 / 1000, 0, 44.25 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(44.25 / 1000, -24 / 1000, 0, 44.25 / 1000, 3 / 1000, 0)
            Part.SketchManager.CreateLine(44.25 / 1000, 3 / 1000, 0, 39.25 / 1000, 3 / 1000, 0)


            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 4.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round insert 4")

            '*********************************************************************
            'creat new part for punch no.5   


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(0 / 1000, 10 / 1000, -10 / 1000)
            Part.SketchManager.CreatePoint(0 / 1000, 10 / 1000, 0 / 1000)
            Part.SketchManager.CreatePoint(0 / 1000, 0 / 1000, 10 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", 0 / 1000, 10 / 1000, -10 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 0 / 1000, 10 / 1000, 0 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 0 / 1000, 0 / 1000, 10 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 5 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 5 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateLine(0 / 1000, 11 / 1000, 0, 0 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(0 / 1000, 61 / 1000, 0, -15 / 1000, 61 / 1000, 0)
            Part.SketchManager.CreateLine(-15 / 1000, 61 / 1000, 0, -15 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(-15 / 1000, 56 / 1000, 0, -12 / 1000, 56 / 1000, 0)
            Part.SketchManager.CreateLine(-12 / 1000, 56 / 1000, 0, -12 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(-12 / 1000, 36 / 1000, 0, -10 / 1000, 36 / 1000, 0)
            Part.SketchManager.CreateLine(-10 / 1000, 36 / 1000, 0, -10 / 1000, 11 / 1000, 0)
            Part.SketchManager.CreateLine(-10 / 1000, 11 / 1000, 0, 0 / 1000, 11 / 1000, 0)



            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 5.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round punch 5")

            '*****************************************************************************

            'creat new part for insert no. 5


            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(0 / 1000, 10 / 1000, -10 / 1000)
            Part.SketchManager.CreatePoint(0 / 1000, 10 / 1000, 0 / 1000)
            Part.SketchManager.CreatePoint(0 / 1000, 0 / 1000, 10 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", 0 / 1000, 10 / 1000, -10 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 0 / 1000, 10 / 1000, 0 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 0 / 1000, 0 / 1000, 10 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "insert 5 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("insert 5 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            Part.SketchManager.CreateCenterLine(0 / 1000, 10 / 1000, 0 / 1000, 0 / 1000, 0 / 1000, 0 / 1000)
            Part.SketchManager.CreateLine(10.5 / 1000, 3 / 1000, 0, 10.5 / 1000, -7 / 1000, 0)
            Part.SketchManager.CreateLine(10.5 / 1000, -7 / 1000, 0, 11.3 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(11.3 / 1000, -32 / 1000, 0, 21.3 / 1000, -32 / 1000, 0)
            Part.SketchManager.CreateLine(21.3 / 1000, -32 / 1000, 0, 21.3 / 1000, -25 / 1000, 0)
            Part.SketchManager.CreateLine(21.3 / 1000, -25 / 1000, 0, 20.3 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(20.3 / 1000, -24 / 1000, 0, 15.5 / 1000, -24 / 1000, 0)
            Part.SketchManager.CreateLine(15.5 / 1000, -24 / 1000, 0, 15.5 / 1000, 3 / 1000, 0)
            Part.SketchManager.CreateLine(15.5 / 1000, 3 / 1000, 0, 10.5 / 1000, 3 / 1000, 0)



            Part.ViewZoomtofit2()

            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False

            ' save as 

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 5.SLDPRT", 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round insert 5")


            '*****************************************************************************

            'creat new part for inner rec. punch 

            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreateLine(30 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, -5 / 1000)
            Part.SketchManager.CreateLine(20 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, 5 / 1000)
            Part.SketchManager.CreateLine(20 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, 5 / 1000)
            Part.SketchManager.CreateLine(30 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, -5 / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", 30 / 1000, 10 / 1000, 5 / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 20 / 1000, 10 / 1000, 5 / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", 20 / 1000, 10 / 1000, -5 / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)

            ' plane rename

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "inner rec. punch PL.")
            Part.ClearSelection2(True)
            ' insert offset plane for second punch face 

            Part.Extension.SelectByID2("inner rec. punch PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(264, 45 / 1000, 0, 0, 0, 0) 'mesh 3aref el 264 dh leeh bs lazm ttktb 

            Part.Extension.SelectByID2("Plane2", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "inner rec. punch Upper PL.")
            Part.ClearSelection2(True)

            ' Extrude 3d sketch up to surface 

            Part.Extension.SelectByID2("3DSketch1", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.Extension.SelectByID2("inner rec. punch Upper PL.", "PLANE", 0, 0, 0, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("inner rec. punch PL.", "PLANE", 0, 0, 0, True, 16, Nothing, 0)

            Part.FeatureManager.FeatureExtrusion2(True, False, False, 4, 0, 0.01, 0.01, False, False, False, False, 0, 0, False, False, False, False, True, True, True, 0, 0, False)


            Part.Extension.SelectByID2("inner rec. punch Upper PL.", "PLANE", 0, 0, 0, True, 1, Nothing, 0)

            Part.SketchManager.CreateLine(-27.5 / 1000, -7.5 / 1000, 0, 22.5 / 100, -7.5 / 1000, 0)
            Part.SketchManager.CreateTangentArc(22.5 / 100, -7.5 / 1000, 0, 20 / 1000, -5 / 1000, 0, 1)
            Part.SketchManager.CreateLine(20 / 1000, -5 / 1000, 0, 20 / 1000, 5 / 1000, 0)
            Part.SketchManager.CreateTangentArc(20 / 1000, 5 / 1000, 0, 22.5 / 1000, 7.5 / 1000, 0, 1)
            Part.SketchManager.CreateLine(22.5 / 1000, 7.5 / 1000, 0, 27.5 / 1000, 7.5, 0)
            Part.SketchManager.CreateTangentArc(27.5 / 1000, 7.5, 0, 30 / 1000, 5 / 1000, 0, 1)
            Part.SketchManager.CreateLine(30 / 1000, 5 / 1000, 0, 30 / 1000, -5 / 1000, 0)
            Part.SketchManager.CreateTangentArc(30 / 1000, -5 / 1000, 0, 27.5 / 1000, -7.5 / 1000, 0, 1)

            Part.FeatureManager.FeatureExtrusion2(True, False, False, 0, 0, 0.005, 0.005, False, False, False, False, 0, 0, False, False, False, False, True, True, True, 0, 0, False)

            '----------------------------------------------------------------------------------------
            ' App.NewAssembly()

            Dim longstatus As Long, longwarnings As Long
            Dim swSheetWidth As Double
            swSheetWidth = 0
            Dim swSheetHeight As Double
            swSheetHeight = 0
            Part = App.NewDocument("C:\ProgramData\SolidWorks\SOLIDWORKS 2022\templates\Assembly.asmdot", 0, swSheetWidth, swSheetHeight)

            '*********************************************************

            '''''''''Dim swAssembly As AssemblyDoc
            swAssembly = Part
            App.ActivateDoc2("Assem1", False, longstatus)
            Part = App.ActiveDoc

            ' Take Snapshot
            Dim swSnapShot As SnapShot
            swSnapShot = Part.ModelViewManager.AddSnapShot("Home")

            ' Insert Component
            Dim AssemblyTitle As String
            AssemblyTitle = Part.GetTitle
            Dim tmpObj As ModelDoc2
            Dim errors As Long
            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\part 5.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)

            '''''''Dim swInsertedComponent As Component2

            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\part 5.SLDPRT", 0, "", False, "", 0.0410338540730521, 0.0528302347617826, 0.0777618228191036)
            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\part 5.SLDPRT")
            Dim TransformData() As Double
            ReDim TransformData(0 To 15)
            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0
            Dim TransformDataVariant
            TransformDataVariant = TransformData
            Dim swMathUtil As Object
            swMathUtil = App.GetMathUtility()
            Dim swTransform As Object
            swTransform = swMathUtil.CreateTransform("TransformDataVariant")
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)

            ' save as assembly

            ' Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\punch assembly 5.SLDASM", 0, 0)


            '**************************************************************

            'insert punch 1 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 1.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 1.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 1.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


            '**************************************************************

            'insert insert 1 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 1.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 1.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 1.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)
            '****************************************************************************************


            'insert punch 2 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 2.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 2.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 2.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)

            '**************************************************************

            'insert insert 2 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 2.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 2.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 2.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)
            '****************************************************************************************

            'insert punch 3 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 3.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 3.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 3.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


            '**************************************************************

            'insert insert 3 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 3.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 3.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 3.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)

            '****************************************************************************************


            'insert punch 4 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 4.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 4.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 4.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)

            '**************************************************************

            'insert insert 4 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 4.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 4.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 4.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)
            '****************************************************************************************


            'insert punch 5 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 5.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 5.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round punch 5.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


            '**************************************************************

            'insert insert 5 to assembly 


            tmpObj = App.OpenDoc6("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 5.SLDPRT", 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 5.SLDPRT", 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc("C:\Users\user\OneDrive\Desktop\punch samples\5\Round insert 5.SLDPRT")

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)
            '***************************************************
            '' insert part to assemly doc 


            'Dim swFeature As Face2
            'swSelMgr = Part.SelectionManager
            'swFeature = swSelMgr.GetSelectedObject6(1, 0)
            ' status = swAssembly.InsertNewVirtualPart(swFeature, swInsertedComponent)

            'Part.Extension.SelectByID2("Part4^punch assembly 5-1@punch assembly 5", "COMPONENT", 0, 0, 0, False, 0, Nothing, 0)
            'Part.ClearSelection2(True)
            'Part.Extension.SelectByID2("Part4^punch assembly 5-1@punch assembly 5", "COMPONENT", 0, 0, 0, False, 0, Nothing, 0)
            ' swInsertedComponent = swSelMgr.GetSelectedObject6(1, -1)
            ' swInsertedComponent.Name2 = "punch 1 "

            ''Part.ClearSelection2(True)

            '' edit part 


            'Part.Extension.SelectByID2("punch 1^punch assembly 5-1@punch assembly 5", "COMPONENT", 0, 0, 0, False, 0, Nothing, 0)
            'Part.EditPart
            'Part.ClearSelection2(True)

            ''insert new sketch on front plane 


            'Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            'Part.SketchManager.InsertSketch(True)

            'Part.SketchManager.CreateLine(0, 11 / 1000, 0, 0, 111 / 1000, 0)
            'Part.SketchManager.CreateLine(0, 111 / 1000, 0, 15 / 1000, 111 / 1000, 0)
            'Part.SketchManager.CreateLine(15 / 1000, 111 / 1000, 0, 15 / 1000, 101 / 1000, 0)
            'Part.SketchManager.CreateLine(15 / 1000, 101 / 1000, 0, 11 / 1000, 101 / 1000, 0)
            'Part.SketchManager.CreateLine(11 / 1000, 101 / 1000, 0, 11 / 1000, 51 / 1000, 0)
            'Part.SketchManager.CreateLine(11 / 1000, 51 / 1000, 0, 10 / 1000, 51 / 1000, 0)
            'Part.SketchManager.CreateLine(10 / 1000, 51 / 1000, 0, 10 / 1000, 11 / 1000, 0)
            'Part.SketchManager.CreateLine(10 / 1000, 11 / 1000, 0, 0, 11 / 1000, 0)
            'Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            'Part.ClearSelection2(True)
            'boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)
            'Dim myFeature As Object
            'myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            'Part.SelectionManager.EnableContourSelection = False

            Part.SaveAs3("C:\Users\user\OneDrive\Desktop\punch samples\5\punch assembly 5.SLDASM", 0, 0)


        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        Dim outerContourData As List(Of List(Of Object))
        Dim innerContoursData As List(Of List(Of Object))
        Dim dataDict As Dictionary(Of String, Object)
        Using client As New HttpClient()

            ' Set the base URL of the REST API
            Dim apiUrl As String = "http://127.0.0.1:8000/"

            ' Append the endpoint or resource path to the base URL
            'Dim apiEndpoint As String = stepFilePath

            ' Create the full URL by combining the base URL and endpoint
            Dim fullUrl As String = apiUrl & "file-path\?path=" & stepFilePath

            ' Send a GET request to the API
            Dim response As HttpResponseMessage = client.GetAsync(fullUrl).Result

            ' Check if the request was successful (status code 200)
            If response.IsSuccessStatusCode Then
                ' Read the response content as a string
                Dim responseContent As String = response.Content.ReadAsStringAsync().Result
                Console.WriteLine(responseContent)
                dataDict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(responseContent)
                outerContourData = dataDict("outer contour data").ToObject(Of List(Of List(Of Object)))()
                'Dim outerContourData As List(Of List(Of Object)) = DirectCast(dataDict("outer contour data"), List(Of List(Of Object)))
                Console.WriteLine(dataDict("inner_contours_data"))
                innerContoursData = dataDict("inner_contours_data").ToObject(Of List(Of List(Of Object)))()
            End If
        End Using



        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean
        Dim swAssembly As AssemblyDoc
        Dim swInsertedComponent As Component2
        Dim swSelMgr As SelectionMgr
        Dim objFSO As Object
        Dim objFile As Object
        Dim compName As String
        Dim splits As Object
        Dim status As Integer


        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True

        '*********************************************************************

        ' creat new part 

        Part = App.NewPart()

        '*********************************************************************

        If Part IsNot Nothing Then


            ' any two lines from the outer contour 
            ' get it later from step api

            Dim p1 As Double() = {outerContourData(0)(1) / 1000, outerContourData(0)(2) / 1000, outerContourData(0)(3) / 1000}
            Dim p2 As Double() = {outerContourData(0)(5) / 1000, outerContourData(0)(6) / 1000, outerContourData(0)(7) / 1000}
            Dim p3 As Double() = {outerContourData(1)(1) / 1000, outerContourData(1)(2) / 1000, outerContourData(1)(3) / 1000}
            Dim p4 As Double() = {outerContourData(1)(5) / 1000, outerContourData(1)(6) / 1000, outerContourData(1)(7) / 1000}

            'line1 
            Dim line1_x1 As Decimal = outerContourData(0)(1) / 1000
            Dim line1_y1 As Decimal = outerContourData(0)(2) / 1000
            Dim line1_z1 As Decimal = outerContourData(0)(3) / 1000

            Dim line1_x2 As Decimal = outerContourData(0)(5) / 1000
            Dim line1_y2 As Decimal = outerContourData(0)(6) / 1000
            Dim line1_z2 As Decimal = outerContourData(0)(7) / 1000

            'line2
            Dim line2_x1 As Decimal = outerContourData(1)(1) / 1000
            Dim line2_y1 As Decimal = outerContourData(1)(2) / 1000
            Dim line2_z1 As Decimal = outerContourData(1)(3) / 1000

            Dim line2_x2 As Decimal = outerContourData(1)(5) / 1000
            Dim line2_y2 As Decimal = outerContourData(1)(6) / 1000
            Dim line2_z2 As Decimal = outerContourData(1)(7) / 1000       'create FACE_OUTER_BOUND plan
            Dim sketchName As String
            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreateLine(line1_x1, line1_y1, line1_z1, line1_x2, line1_y2, line1_z2)
            Part.SketchManager.CreateLine(line2_x1, line2_y1, line2_z1, line2_x2, line2_y2, line2_z2)

            Part.SketchManager.Insert3DSketch(True)

            'Part.ClearSelection2(True)
            'Part.SketchManager.InsertSketch(True)
            Part.ClearSelection2(True)



            If (p1(0) <> p2(0) Or p1(2) <> p2(2)) And (p1(0) <> p3(0) Or p1(2) <> p3(2)) And (p2(0) <> p3(0) Or p2(2) <> p3(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p1(0), p1(1), p1(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p2(0), p2(1), p2(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p3(0), p3(1), p3(2), True, 2, Nothing, 0)




            ElseIf (p1(0) <> p2(0) Or p1(2) <> p2(2)) And (p1(0) <> p4(0) Or p1(2) <> p4(2)) And (p2(0) <> p4(0) Or p2(2) <> p4(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p1(0), p1(1), p1(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p2(0), p2(1), p2(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p4(0), p4(1), p4(2), True, 2, Nothing, 0)



            ElseIf (p3(0) <> p2(0) Or p3(2) <> p2(2)) And (p3(0) <> p4(0) Or p3(2) <> p4(2)) And (p2(0) <> p4(0) Or p2(2) <> p4(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p3(0), p3(1), p3(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p2(0), p2(1), p2(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p4(0), p4(1), p4(2), True, 2, Nothing, 0)



            ElseIf (p3(0) <> p1(0) Or p3(2) <> p1(2)) And (p3(0) <> p4(0) Or p3(2) <> p4(2)) And (p1(0) <> p4(0) Or p1(2) <> p4(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p3(0), p3(1), p3(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p1(0), p1(1), p1(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p4(0), p4(1), p4(2), True, 2, Nothing, 0)

            End If

            'Part.Extension.SelectByID2("", "SketchPoint", line1_x2, line1_y2, line1_z2, True, 0, Nothing, 0)
            'Part.Extension.SelectByID2("", "SketchPoint", line2_x2, line2_y2, line2_z2, True, 1, Nothing, 0)
            'Part.Extension.SelectByID2("", "SketchPoint", line2_x1, line2_y1, line2_z1, True, 2, Nothing, 0)

            'Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)
            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)
            ' plane rename 
            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B plane")
            Part.ClearSelection2(True)

            'hide sketch 
            Part.Extension.SelectByID2("3DSketch1", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.BlankSketch()

            '*********************************************************************


            'insert 3d sketch for outer boundry
            Dim outer_bound_thickness = 0.006


            Part.SketchManager.Insert3DSketch(True)

            For Each entity In outerContourData
                Console.WriteLine(entity(8))
                If entity(8) = "LINE" Then
                    Part.SketchManager.CreateLine(entity(1) / 1000, entity(2) / 1000, entity(3) / 1000, entity(5) / 1000, entity(6) / 1000, entity(7) / 1000)
                ElseIf entity(8) = "CIRCLE" Then
                    Part.SketchManager.CreateTangentArc(entity(1) / 1000, entity(2) / 1000, entity(3) / 1000, entity(5) / 1000, entity(6) / 1000, entity(7) / 1000, 1)
                End If
            Next


            ' Rename for outer bound sketch 

            Part.Extension.SelectByID2("3DSketch2", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B Sketch")

            'extrude for outer bound 
            Part.Extension.SelectByID2("O.B Sketch", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, outer_bound_thickness, outer_bound_thickness, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)
            Part.SelectionManager.EnableContourSelection = False

            '*********************************************************************

            ' inner bound 

            Console.WriteLine("-------------------------")
            'Console.WriteLine(dataDict("inner_contours_data")(0)(0)(8))
            Dim i As Integer = 0
            Dim j As Integer = 0
            Dim c As Integer = 0
            For Each facebound In dataDict("inner_contours_data")
                If dataDict("inner_contours_data")(c)(0)(8) = "LINE" Then
                    Part.ClearSelection2(True)
                    Part.SketchManager.Insert3DSketch(True)

                    ' Select the newly created 3D sketch
                    Part.Extension.SelectByID2("3DSketch" & i + 3, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)

                    ' Rename the selected 3D sketch
                    sketchName = "inner contour 3d" & i + 1
                    Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, sketchName)

                ElseIf dataDict("inner_contours_data")(c)(0)(8) = "CIRCLE" Then
                    Part.ClearSelection2(True)

                    Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
                    Part.SketchManager.InsertSketch(True)
                    Part.Extension.SelectByID2("Sketch" & j + 1, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)

                    ' Rename the selected 3D sketch
                    sketchName = "inner contour 2d" & j + 1
                    Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, sketchName)


                End If

                For Each entity In facebound
                    Console.WriteLine("entity:")
                    Console.WriteLine(entity)
                    If entity(8) = "LINE" Then
                        Part.SketchManager.CreateLine(entity(1) / 1000, entity(2) / 1000, entity(3) / 1000, entity(5) / 1000, entity(6) / 1000, entity(7) / 1000)

                    ElseIf entity(8) = "CIRCLE" Then
                        Console.WriteLine("entity 9:" & entity(9).ToString() & " entity 11:" & entity(11).ToString() & " radius" & entity(12).ToString())
                        Part.SketchManager.CreateCircleByRadius(entity(9) / 1000, -entity(11) / 1000, 0, entity(12) / 1000)
                    End If
                Next


                If dataDict("inner_contours_data")(c)(0)(8) = "LINE" Then
                    ' Extrude cut for the inner bound in the 3D sketch
                    Part.Extension.SelectByID2(sketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
                    Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0)
                    Part.FeatureManager.FeatureCut4(True, False, True, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)
                    i = i + 1

                ElseIf dataDict("inner_contours_data")(c)(0)(8) = "CIRCLE" Then
                    Part.Extension.SelectByID2(sketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
                    Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0)

                    ' Extrude cut holes inner bound 
                    Part.FeatureManager.FeatureCut4(True, False, False, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)
                    j = j + 1

                End If

                c = c + 1
            Next

            Part.ShowNamedView2("*Isometric", 7)
            Part.ViewZoomtofit2()

            'Dim sketchName As String = If(i = 0, "O.B Sketch", "I.B Sketch" & i)

            'Part.Extension.SelectByID2("3DSketch" & (i + 3), "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            '' Rename the sketch
            'Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, sketchName)

            '' Extrude cut for the inner bound in the 3D sketch

            'Part.Extension.SelectByID2(sketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            'Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0)
            'Part.FeatureManager.FeatureCut4(True, False, True, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)


            ''create internal bound 
            ' Define the coordinates for each face bound
            '    Dim faceBoundsCoordinates As (String, Double, Double, Double, Double, Double, Double)()() = {
            '                                    New(String, Double, Double, Double, Double, Double, Double)() {
            '                                        ("line", 30 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, -5 / 1000),
            '                                        ("line", 20 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, 5 / 1000),
            '                                        ("line", 20 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, 5 / 1000),
            '                                        ("line", 30 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, -5 / 1000)
            '                                    },
            '                                    New(String, Double, Double, Double, Double, Double, Double)() {
            '                                        ("line", -31.57 / 1000, 10 / 1000, 5.84 / 1000, -23.22 / 1000, 10 / 1000, 8.61 / 1000),
            '                                        ("line", -33.35 / 1000, 10 / 1000, -2.77 / 1000, -31.57 / 1000, 10 / 1000, 5.84 / 1000),
            '                                        ("line", -26.77 / 1000, 10 / 1000, -8.61 / 1000, -33.35 / 1000, 10 / 1000, -2.77 / 1000),
            '                                        ("line", -18.43 / 1000, 10 / 1000, -5.84 / 1000, -26.77 / 1000, 10 / 1000, -8.61 / 1000),
            '                                        ("line", -16.65 / 1000, 10 / 1000, 2.76 / 1000, -18.43 / 1000, 10 / 1000, -5.84 / 1000),
            '                                        ("line", -23.22 / 1000, 10 / 1000, 8.61 / 1000, -16.65 / 1000, 10 / 1000, 2.76 / 1000)
            '                                    },
            '                                    New(String, Double, Double, Double, Double, Double, Double)() {
            '                                        ("circle", 35 / 1000, 35 / 1000, 0, 4 / 1000, 0, 0),
            '                                        ("circle", -35 / 1000, -35 / 1000, 0, 4 / 1000, 0, 0),
            '                                        ("circle", 0, 0, 0, 10 / 1000, 0, 0),
            '                                        ("circle", 35 / 1000, -35 / 1000, 0, 4 / 1000, 0, 0),
            '                                        ("circle", -35 / 1000, 35 / 1000, 0, 4 / 1000, 0, 0)
            '                                    }
            '                                }

            '    ' Iterate over the face bounds coordinates and create sketches
            '    For i As Integer = 0 To faceBoundsCoordinates.Length - 1
            '        Dim sketchName As String = If(i = 0, "O.B Sketch", "I.B Sketch" & i)

            '        ' Create the 3D sketch

            '        If faceBoundsCoordinates(i)(0).Item1 = "line" Then
            '            Part.SketchManager.Insert3DSketch(True)

            '        ElseIf faceBoundsCoordinates(i)(0).Item1 = "circle" Then
            '            Part.ClearSelection2(True)

            '            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            '            Part.SketchManager.InsertSketch(True)


            '        End If


            '        ' Create the sketch entities based on the coordinates
            '        For Each coord In faceBoundsCoordinates(i)
            '            If coord.Item1 = "line" Then
            '                Part.SketchManager.CreateLine(coord.Item2, coord.Item3, coord.Item4, coord.Item5, coord.Item6, coord.Item7)

            '            ElseIf coord.Item1 = "circle" Then
            '                Part.SketchManager.CreateCircleByRadius(coord.Item2, coord.Item3, coord.Item4, coord.Item5)

            '            End If
            '        Next



            '        If faceBoundsCoordinates(i)(0).Item1 = "line" Then
            '            Part.Extension.SelectByID2("3DSketch" & (i + 3), "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            '            ' Rename the sketch
            '            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, sketchName)

            '            ' Extrude cut for the inner bound in the 3D sketch

            '            Part.Extension.SelectByID2(sketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            '            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0)
            '            Part.FeatureManager.FeatureCut4(True, False, True, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)

            '        ElseIf faceBoundsCoordinates(i)(0).Item1 = "circle" Then
            '            Part.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            '            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "Holes Sketch")

            '            'extrude cut holes inner bound 


            '            Part.FeatureManager.FeatureCut4(True, False, False, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)

            '            '*********************************************************************

            '            ' iso metric view And save 

            '            Part.ShowNamedView2("*Isometric", 7)
            '            Part.ViewZoomtofit2()


            'End If


            'Next

            '*********************************************************************

            ''create FACE_BOUND 1 

            'Part.SketchManager.Insert3DSketch(True)

            'Part.SketchManager.CreateLine(30 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, -5 / 1000)
            'Part.SketchManager.CreateLine(20 / 1000, 10 / 1000, 5 / 1000, 30 / 1000, 10 / 1000, 5 / 1000)
            'Part.SketchManager.CreateLine(20 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, 5 / 1000)
            'Part.SketchManager.CreateLine(30 / 1000, 10 / 1000, -5 / 1000, 20 / 1000, 10 / 1000, -5 / 1000)

            ''create FACE_BOUND 2 

            'Part.SketchManager.CreateLine(-31.57 / 1000, 10 / 1000, 5.84 / 1000, -23.22 / 1000, 10 / 1000, 8.61 / 1000)
            'Part.SketchManager.CreateLine(-33.35 / 1000, 10 / 1000, -2.77 / 1000, -31.57 / 1000, 10 / 1000, 5.84 / 1000)
            'Part.SketchManager.CreateLine(-26.77 / 1000, 10 / 1000, -8.61 / 1000, -33.35 / 1000, 10 / 1000, -2.77 / 1000)
            'Part.SketchManager.CreateLine(-18.43 / 1000, 10 / 1000, -5.84 / 1000, -26.77 / 1000, 10 / 1000, -8.61 / 1000)
            'Part.SketchManager.CreateLine(-16.65 / 1000, 10 / 1000, 2.76 / 1000, -18.43 / 1000, 10 / 1000, -5.84 / 1000)
            'Part.SketchManager.CreateLine(-23.22 / 1000, 10 / 1000, 8.61 / 1000, -16.65 / 1000, 10 / 1000, 2.76 / 1000)

            ''rename inner bound 3d sketch 
            'Part.Extension.SelectByID2("3DSketch3", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            'Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "I.B Sketch")

            ''extrude cut for inner bound in 3d sketch 
            'Part.Extension.SelectByID2("I.B Sketch", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            'Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            'Part.FeatureManager.FeatureCut4(True, False, True, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)

            ''*********************************************************************


            ''create FACE_BOUND 3

            'Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            'Part.SketchManager.InsertSketch(True)
            'Part.SketchManager.CreateCircleByRadius(35 / 1000, 35 / 1000, 0, 4 / 1000)
            'Part.SketchManager.CreateCircleByRadius(-35 / 1000, -35 / 1000, 0, 4 / 1000)
            'Part.SketchManager.CreateCircleByRadius(0, 0, 0, 10 / 1000)
            'Part.SketchManager.CreateCircleByRadius(35 / 1000, -35 / 1000, 0, 4 / 1000)
            'Part.SketchManager.CreateCircleByRadius(-35 / 1000, 35 / 1000, 0, 4 / 1000)

            ''Rename for sketch 
            'Part.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            'Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "Holes Sketch")

            ''extrude cut holes inner bound 


            'Part.FeatureManager.FeatureCut4(True, False, False, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)

            '*********************************************************************

            ' iso metric view and save 

            'Part.ShowNamedView2("*Isometric", 7)
            'Part.ViewZoomtofit2()

            Part.SaveAs3(partFilePath, 0, 0)

        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs)

        Dim openFileDialog1 As New OpenFileDialog()
        Dim stepFilePath As String
        openFileDialog1.InitialDirectory = "C:\" ' Set the initial directory for the dialog
        openFileDialog1.Filter = "All files (*.*)|*.*" ' Set the file filter
        openFileDialog1.RestoreDirectory = True ' Restore the directory to the previously selected one

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            stepFilePath = openFileDialog1.FileName
            ' Do something with the selected file path, such as displaying it in a textbox
        End If

        Using client As New HttpClient()
            ' Set the base URL of the REST API
            Dim apiUrl As String = "http://127.0.0.1:8000/"

            ' Append the endpoint or resource path to the base URL
            'Dim apiEndpoint As String = stepFilePath

            ' Create the full URL by combining the base URL and endpoint
            Dim fullUrl As String = apiUrl & "file-path\?path=" & stepFilePath

            ' Send a GET request to the API
            Dim response As HttpResponseMessage = client.GetAsync(fullUrl).Result

            ' Check if the request was successful (status code 200)
            If response.IsSuccessStatusCode Then
                ' Read the response content as a string
                Dim responseContent As String = response.Content.ReadAsStringAsync().Result
                Console.WriteLine(responseContent)
                Dim dataDict As Dictionary(Of String, Object) = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(responseContent)
                Dim outerContourData As List(Of List(Of Object)) = dataDict("outer contour data").ToObject(Of List(Of List(Of Object)))()
                'Dim outerContourData As List(Of List(Of Object)) = DirectCast(dataDict("outer contour data"), List(Of List(Of Object)))
                Dim innerContoursData As List(Of List(Of Object)) = dataDict("inner_contours_data").ToObject(Of List(Of List(Of Object)))()

                'Dim innerContoursData As List(Of List(Of Object)) = DirectCast(dataDict("inner_contours_data"), List(Of List(Of Object)))
                For Each element In outerContourData
                    ' Access the elements inside the outer contour data
                    ' Do something with the data elements, such as printing or processing
                    Console.WriteLine(element(0) & "-" & element(1))
                Next
                ' Print the response content
                Console.WriteLine(responseContent)
            Else
                ' Print the error status code
                Console.WriteLine("Error: " & response.StatusCode)
            End If
        End Using
    End Sub


    Function ResizeArray(Of T)(array As T(), newSize As Integer) As T()
        Dim newArray(newSize - 1) As T
        array.Copy(array, newArray, Math.Min(array.Length, newSize))
        Return newArray
    End Function


    Private Sub Button7_Click_1(sender As Object, e As EventArgs) Handles Button7.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean
        Dim swAssembly As AssemblyDoc
        Dim swInsertedComponent As Component2
        Dim swSelMgr As SelectionMgr
        Dim objFSO As Object
        Dim objFile As Object
        Dim compName As String
        Dim splits As Object
        Dim status As Integer

        PunchContoursData = api.GetPunchContours()

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True
        'create plane before starting
        Dim punch_num = 1
        For Each contour In PunchContoursData
            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(1)(1)) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(1)(1)) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 1 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 1 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            For Each entity In contour
                Part.SketchManager.CreateLine(-Convert.ToInt32(entity(1)) / 1000, Convert.ToInt32(entity(2)) / 1000, 0, -Convert.ToInt32(entity(5)) / 1000, Convert.ToInt32(entity(6)) / 1000, 0)
            Next
            Part.ViewZoomtofit2()



            ' if its last two contours they should be made using extrude boss? 
            'revolve boss 

            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 16, Nothing, 0)
            Dim myFeature As Object
            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False



            ' save as 
            Dim part_name As String = folder & "\" & "Round Punch" & Convert.ToString(punch_num) & ".SLDPRT"

            punchLst = ResizeArray(punchLst, punch_num)
            punchLst(punch_num - 1) = part_name

            Part.SaveAs3(part_name, 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round punch" & Convert.ToString(punch_num))
            punch_num = punch_num + 1


        Next


        '' App.NewAssembly()

        'Dim longstatus As Long, longwarnings As Long
        'Dim swSheetWidth As Double
        'swSheetWidth = 0
        'Dim swSheetHeight As Double
        'swSheetHeight = 0
        'Part = App.NewDocument("C:\ProgramData\SolidWorks\SOLIDWORKS 2022\templates\Assembly.asmdot", 0, swSheetWidth, swSheetHeight)

        ''*********************************************************

        ''''''''''Dim swAssembly As AssemblyDoc
        'swAssembly = Part
        'App.ActivateDoc2("Assem1", False, longstatus)
        'Part = App.ActiveDoc

        '' Take Snapshot
        'Dim swSnapShot As SnapShot
        'swSnapShot = Part.ModelViewManager.AddSnapShot("Home")

        '' Insert Component
        'Dim AssemblyTitle As String
        'AssemblyTitle = Part.GetTitle
        'Dim tmpObj As ModelDoc2
        'Dim errors As Long
        'tmpObj = App.OpenDoc6(partFilePath, 1, 32, "", errors, longwarnings)
        'Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)

        ''''''''Dim swInsertedComponent As Component2

        'swInsertedComponent = swAssembly.AddComponent5(partFilePath, 0, "", False, "", 0.0410338540730521, 0.0528302347617826, 0.0777618228191036)
        'App.CloseDoc(partFilePath)
        'Dim TransformData() As Double
        'ReDim TransformData(0 To 15)
        'TransformData(0) = 1
        'TransformData(1) = 0
        'TransformData(2) = 0
        'TransformData(3) = 0
        'TransformData(4) = 1
        'TransformData(5) = 0
        'TransformData(6) = 0
        'TransformData(7) = 0
        'TransformData(8) = 1
        'TransformData(9) = 0
        'TransformData(10) = 0
        'TransformData(11) = 0
        'TransformData(12) = 1
        'TransformData(13) = 0
        'TransformData(14) = 0
        'TransformData(15) = 0
        'Dim TransformDataVariant
        'TransformDataVariant = TransformData
        'Dim swMathUtil As Object
        'swMathUtil = App.GetMathUtility()
        'Dim swTransform As Object
        'swTransform = swMathUtil.CreateTransform("TransformDataVariant")
        'boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)

        '' save as assembly

        'For Each punchPath As String In punchLst
        '    Console.WriteLine(punchPath)

        '    tmpObj = App.OpenDoc6(punchPath, 1, 32, "", errors, longwarnings)
        '    Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



        '    swInsertedComponent = swAssembly.AddComponent5(punchPath, 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

        '    App.CloseDoc(punchPath)

        '    TransformData(0) = 1
        '    TransformData(1) = 0
        '    TransformData(2) = 0
        '    TransformData(3) = 0
        '    TransformData(4) = 1
        '    TransformData(5) = 0
        '    TransformData(6) = 0
        '    TransformData(7) = 0
        '    TransformData(8) = 1
        '    TransformData(9) = 0
        '    TransformData(10) = 0
        '    TransformData(11) = 0
        '    TransformData(12) = 1
        '    TransformData(13) = 0
        '    TransformData(14) = 0
        '    TransformData(15) = 0

        '    TransformDataVariant = TransformData

        '    swMathUtil = App.GetMathUtility()

        '    swTransform = swMathUtil.CreateTransform((TransformDataVariant))
        '    boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


        'Next


        'Part.SaveAs3(folder & "\assembly.SLDASM", 0, 0)

        '' inner bound 

        'Console.WriteLine("-------------------------")
        ''Console.WriteLine(dataDict("inner_contours_data")(0)(0)(8))
        'For Each facebound In PunchContoursData
        '    For Each entity In facebound
        '        Console.WriteLine("entity:")
        '        Console.WriteLine(entity)
        '    Next
        'Next

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        ResetVariables()
        Dim openFileDialog1 As New OpenFileDialog()
        openFileDialog1.InitialDirectory = "C:\" ' Set the initial directory for the dialog
        openFileDialog1.Filter = "All files (*.*)|*.*" ' Set the file filter
        openFileDialog1.RestoreDirectory = True ' Restore the directory to the previously selected one

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            stepFilePath = openFileDialog1.FileName
            TextBox1.Text = stepFilePath
            folder = Path.GetDirectoryName(stepFilePath)
            partFilePath = folder & "\" & Path.GetFileNameWithoutExtension(stepFilePath) & ".sldprt"
            ' Do something with the selected file path, such as displaying it in a textbox
            api.GetStepFile(stepFilePath)

        End If


    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean
        Dim swAssembly As AssemblyDoc
        Dim swInsertedComponent As Component2
        Dim swSelMgr As SelectionMgr
        Dim objFSO As Object
        Dim objFile As Object
        Dim compName As String
        Dim splits As Object
        Dim status As Integer
        ' die drawing

        PunchContoursData = api.GetDieContours()
        centerpoint = api.GetCenterPoint()

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True
        'create plane before starting
        Dim punch_num = 1
        Dim dieList As String() = {} ' Empty string array
        For Each contour In PunchContoursData
            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000)
            Part.SketchManager.CreatePoint((Convert.ToInt32(contour(1)(1)) + 10) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000) ' added 10 to x because an error happens when the die points at the same line the plane won't created
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)






            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", (Convert.ToInt32(contour(1)(1)) + 10) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 1 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 1 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Console.WriteLine("center point")
            Console.WriteLine(Convert.ToInt32(contour(0)(9)).ToString() & Convert.ToInt32(contour(0)(10)).ToString() & Convert.ToInt32(contour(0)(11)).ToString())
            Console.WriteLine("punch num:" & punch_num)
            Part.SketchManager.InsertSketch(True)
            Part.SketchManager.CreateCenterLine(-Convert.ToInt32(contour(0)(9)) / 1000, Convert.ToInt32(contour(0)(10)) / 1000, Convert.ToInt32(contour(0)(11)) / 1000, -Convert.ToInt32(contour(0)(9)) / 1000, Convert.ToInt32(contour(0)(10)) / 1000 + 1 / 1000, Convert.ToInt32(contour(0)(11)) / 1000)
            For Each entity In contour
                Part.SketchManager.CreateLine(-Convert.ToInt32(entity(1)) / 1000, Convert.ToInt32(entity(2)) / 1000, 0, -Convert.ToInt32(entity(5)) / 1000, Convert.ToInt32(entity(6)) / 1000, 0)
            Next
            Part.ViewZoomtofit2()

            'revolve boss 
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, True, 0, Nothing, 0)
            Part.ClearSelection2(True)
            boolstatus = Part.Extension.SelectByID2("Line1", "SKETCHSEGMENT", -4.50637857943053, -55.0378853083627, -8.92482687096527, False, 5, Nothing, 0)
            Dim myFeature As Object

            myFeature = Part.FeatureManager.FeatureRevolve2(True, True, False, False, False, False, 0, 0, 6.2831853071796, 0, False, False, 0.01, 0.01, 0, 0, 0, True, True, True)
            Part.SelectionManager.EnableContourSelection = False



            ' save as 
            Dim part_name As String = folder & "\" & "Round Die" & Convert.ToString(punch_num) & ".SLDPRT"

            dieList = ResizeArray(dieList, punch_num)
            dieList(punch_num - 1) = part_name

            Part.SaveAs3(part_name, 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Round Die" & Convert.ToString(punch_num))
            punch_num = punch_num + 1


        Next




        ' drawing irregular dies

        ' 1.reading dies data from the api 
        IrDieData = api.GetIrregularDieContours()
        Console.WriteLine(IrDieData)

        ' 2. loop over the data to explore its content
        'For Each contour In IrDieData
        '    For Each entity In contour
        '        Console.WriteLine(entity)
        '    Next
        'Next

        'Dim offset_amount = thickness + clearance + dielength 
        Dim offset_amount = 0.05 + 11 / 1000


        For Each contour In IrDieData
            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(0)(1)) / 1000, -(Convert.ToInt32(contour(0)(2)) / 1000 + offset_amount), Convert.ToInt32(contour(0)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(1)(1)) / 1000, -(Convert.ToInt32(contour(1)(2)) / 1000 + offset_amount), Convert.ToInt32(contour(1)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(2)(1)) / 1000, -(Convert.ToInt32(contour(2)(2)) / 1000 + offset_amount), Convert.ToInt32(contour(2)(3)) / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(0)(1)) / 1000, -(Convert.ToInt32(contour(0)(2)) / 1000 + offset_amount), Convert.ToInt32(contour(0)(3)) / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(1)(1)) / 1000, -(Convert.ToInt32(contour(1)(2)) / 1000 + offset_amount), Convert.ToInt32(contour(1)(3)) / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(2)(1)) / 1000, -(Convert.ToInt32(contour(2)(2)) / 1000 + offset_amount), Convert.ToInt32(contour(2)(3)) / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 1 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 1 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            For Each entity In contour
                Part.SketchManager.CreateLine(Convert.ToInt32(entity(1)) / 1000, -Convert.ToInt32(entity(3)) / 1000, 0, Convert.ToInt32(entity(5)) / 1000, -Convert.ToInt32(entity(7)) / 1000, 0)
            Next
            Part.ViewZoomtofit2()



            ' if its last two contours they should be made using extrude boss? 
            'revolve boss 
            'Part.Extension.SelectByID2()
            Part.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, True, 0, Nothing, 0)
            'Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B Sketch")

            'extrude for outer bound 
            'Part.Extension.SelectByID2("O.B Sketch", "SKETCH", 0, 0, 0, True, 1, Nothing, 0)
            'Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            Part.SketchManager.SketchOffset2(0.016, False, True, 0, 0, True)


            ' after offsetting the die should i extrude it to a length equal the other dies 
            Part.FeatureManager.FeatureExtrusion2(True, False, False, 0, 0, 0.05, 0.01, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)
            Part.SelectionManager.EnableContourSelection = False


            ' 1
            'Set myFeature = Part.FeatureManager.FeatureExtrusion2(True, False, False, 0, 0, 0.05, 0.01, False, False, False, False, 1.74532925199433E-02, 1.74532925199433E-02, False, False, False, False, True, True, True, 0, 0, False)
            'Part.SelectionManager.EnableContourSelection = False

            ' 2 
            'Set myFeature = Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, 0.05, 0.05, False, False, False, False, 1.74532925199433E-02, 1.74532925199433E-02, False, False, False, False, True, True, True, 0, 0, False)
            'Part.SelectionManager.EnableContourSelection = False

            ' save as 
            Dim part_name As String = folder & "\" & "ir Die" & Convert.ToString(punch_num) & ".SLDPRT"

            dieList = ResizeArray(dieList, punch_num)
            dieList(punch_num - 1) = part_name

            Part.SaveAs3(part_name, 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("ir Die" & Convert.ToString(punch_num))
            punch_num = punch_num + 1


        Next





        ' App.NewAssembly()

        Dim longstatus As Long, longwarnings As Long
        Dim swSheetWidth As Double
        swSheetWidth = 0
        Dim swSheetHeight As Double
        swSheetHeight = 0
        Part = App.NewDocument("C:\ProgramData\SolidWorks\SOLIDWORKS 2022\templates\Assembly.asmdot", 0, swSheetWidth, swSheetHeight)

        '*********************************************************

        '''''''''Dim swAssembly As AssemblyDoc
        swAssembly = Part
        App.ActivateDoc2("Assem1", False, longstatus)
        Part = App.ActiveDoc

        ' Take Snapshot
        Dim swSnapShot As SnapShot
        swSnapShot = Part.ModelViewManager.AddSnapShot("Home")

        ' Insert Component
        Dim AssemblyTitle As String
        AssemblyTitle = Part.GetTitle
        Dim tmpObj As ModelDoc2
        Dim errors As Long
        tmpObj = App.OpenDoc6(partFilePath, 1, 32, "", errors, longwarnings)
        Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)

        '''''''Dim swInsertedComponent As Component2

        swInsertedComponent = swAssembly.AddComponent5(partFilePath, 0, "", False, "", 0.0410338540730521, 0.0528302347617826, 0.0777618228191036)
        App.CloseDoc(partFilePath)
        Dim TransformData() As Double
        ReDim TransformData(0 To 15)
        TransformData(0) = 1
        TransformData(1) = 0
        TransformData(2) = 0
        TransformData(3) = 0
        TransformData(4) = 1
        TransformData(5) = 0
        TransformData(6) = 0
        TransformData(7) = 0
        TransformData(8) = 1
        TransformData(9) = 0
        TransformData(10) = 0
        TransformData(11) = 0
        TransformData(12) = 1
        TransformData(13) = 0
        TransformData(14) = 0
        TransformData(15) = 0
        Dim TransformDataVariant
        TransformDataVariant = TransformData
        Dim swMathUtil As Object
        swMathUtil = App.GetMathUtility()
        Dim swTransform As Object
        swTransform = swMathUtil.CreateTransform("TransformDataVariant")
        boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)

        ' save as assembly
        Console.WriteLine("punchs", punchLst)
        For Each punchPath As String In punchLst
            Console.WriteLine(punchPath)

            tmpObj = App.OpenDoc6(punchPath, 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5(punchPath, 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc(punchPath)

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


        Next

        For Each punchPath As String In dieList
            Console.WriteLine(punchPath)

            tmpObj = App.OpenDoc6(punchPath, 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5(punchPath, 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc(punchPath)

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


        Next

        ' inserting ext punches into assembly

        For Each punchPath As String In extpunchLst
            Console.WriteLine(punchPath)

            tmpObj = App.OpenDoc6(punchPath, 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5(punchPath, 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc(punchPath)

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


        Next


        ' inserting rect punches into assembly
        For Each punchPath As String In rectpunchLst
            Console.WriteLine(punchPath)

            tmpObj = App.OpenDoc6(punchPath, 1, 32, "", errors, longwarnings)
            Part = App.ActivateDoc3(AssemblyTitle, True, 0, errors)



            swInsertedComponent = swAssembly.AddComponent5(punchPath, 0, "", False, "", 0.0549655250342636, 0.071, 0.104601753283571)

            App.CloseDoc(punchPath)

            TransformData(0) = 1
            TransformData(1) = 0
            TransformData(2) = 0
            TransformData(3) = 0
            TransformData(4) = 1
            TransformData(5) = 0
            TransformData(6) = 0
            TransformData(7) = 0
            TransformData(8) = 1
            TransformData(9) = 0
            TransformData(10) = 0
            TransformData(11) = 0
            TransformData(12) = 1
            TransformData(13) = 0
            TransformData(14) = 0
            TransformData(15) = 0

            TransformDataVariant = TransformData

            swMathUtil = App.GetMathUtility()

            swTransform = swMathUtil.CreateTransform((TransformDataVariant))
            boolstatus = swInsertedComponent.SetTransformAndSolve2(swTransform)


        Next


        Part.SaveAs3(folder & "\assembly.SLDASM", 0, 0)

        ' inner bound 

        Console.WriteLine("-------------------------")
        'Console.WriteLine(dataDict("inner_contours_data")(0)(0)(8))
        For Each facebound In PunchContoursData
            For Each entity In facebound
                Console.WriteLine("entity:")
                Console.WriteLine(entity)
            Next
        Next
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        api.StartServer()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean
        Dim swAssembly As AssemblyDoc
        Dim swInsertedComponent As Component2
        Dim swSelMgr As SelectionMgr
        Dim objFSO As Object
        Dim objFile As Object
        Dim compName As String
        Dim splits As Object
        Dim status As Integer

        PunchContoursData = api.GetExtPunchContours()

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True
        'create plane before starting
        Dim punch_num = 1
        For Each contour In PunchContoursData
            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(1)(1)) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(1)(1)) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 1 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 1 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            For Each entity In contour
                Part.SketchManager.CreateLine(-Convert.ToInt32(entity(1)) / 1000, Convert.ToInt32(entity(3)) / 1000, 0, -Convert.ToInt32(entity(5)) / 1000, Convert.ToInt32(entity(7)) / 1000, 0)
            Next
            Part.ViewZoomtofit2()



            ' if its last two contours they should be made using extrude boss? 
            'revolve boss 
            Part.Extension.SelectByID2("", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B Sketch")

            'extrude for outer bound 
            Part.Extension.SelectByID2("O.B Sketch", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            'Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, 0.05, 0.05, False, False, False, False, 0.0174532925199433, 0.0174532925199433, True, False, False, False, True, True, True, 0, 0, False)
            Part.FeatureManager.FeatureExtrusion2(True, False, False, 6, 0, 0.05, 0.01, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)
            Part.SelectionManager.EnableContourSelection = False


            ' save as 
            Dim part_name As String = folder & "\" & "Extruded Punch" & Convert.ToString(punch_num) & ".SLDPRT"

            extpunchLst = ResizeArray(extpunchLst, punch_num)
            extpunchLst(punch_num - 1) = part_name

            Part.SaveAs3(part_name, 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Extruded punch" & Convert.ToString(punch_num))
            punch_num = punch_num + 1


        Next

    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean
        Dim swAssembly As AssemblyDoc
        Dim swInsertedComponent As Component2
        Dim swSelMgr As SelectionMgr
        Dim objFSO As Object
        Dim objFile As Object
        Dim compName As String
        Dim splits As Object
        Dim status As Integer


        PunchContoursData = api.GetRectPunchContours()

        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        'create plane before starting
        Dim punch_num = 1
        For Each contour In PunchContoursData
            Part = App.NewPart()

            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(1)(1)) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000)
            Part.SketchManager.CreatePoint(Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000)

            Part.ClearSelection2(True)

            Part.SketchManager.InsertSketch(True)

            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(0)(1)) / 1000, Convert.ToInt32(contour(0)(2)) / 1000, Convert.ToInt32(contour(0)(3)) / 1000, True, 0, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(1)(1)) / 1000, Convert.ToInt32(contour(1)(2)) / 1000, Convert.ToInt32(contour(1)(3)) / 1000, True, 1, Nothing, 0)
            Part.Extension.SelectByID2("", "SketchPoint", Convert.ToInt32(contour(2)(1)) / 1000, Convert.ToInt32(contour(2)(2)) / 1000, Convert.ToInt32(contour(2)(3)) / 1000, True, 2, Nothing, 0)

            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)


            ' plane rename 

            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "punch 1 PL.")
            Part.ClearSelection2(True)

            Part.Extension.SelectByID2("punch 1 PL.", "PLANE", 0, 0, 0, False, 0, Nothing, 0)

            Part.SketchManager.InsertSketch(True)

            For Each entity In contour
                Part.SketchManager.CreateLine(Convert.ToInt32(entity(1)) / 1000, -Convert.ToInt32(entity(3)) / 1000, 0, Convert.ToInt32(entity(5)) / 1000, -Convert.ToInt32(entity(7)) / 1000, 0) ' changed y from negative to positive 
            Next
            Part.ViewZoomtofit2()



            ' if its last two contours they should be made using extrude boss? 
            'revolve boss 
            Part.Extension.SelectByID2("", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B Sketch")

            'extrude for outer bound 
            Part.Extension.SelectByID2("O.B Sketch", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            'Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, 0.05, 0.05, False, False, False, False, 0.0174532925199433, 0.0174532925199433, True, False, False, False, True, True, True, 0, 0, False)
            'Part.FeatureManager.FeatureExtrusion2(True, False, True, 6, 0, 0.05, 0.01, False, False, False, False, 0.0174532925199433, 0.0174532925199433, True, False, False, False, True, True, True, 0, 0, False)
            'Part.SelectionManager.EnableContourSelection = False
            'Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)
            Part.FeatureManager.FeatureExtrusion2(True, False, False, 0, 0, 0.05, 0.01, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)
            Part.SelectionManager.EnableContourSelection = False


            ' 1
            'Set myFeature = Part.FeatureManager.FeatureExtrusion2(True, False, False, 0, 0, 0.05, 0.01, False, False, False, False, 1.74532925199433E-02, 1.74532925199433E-02, False, False, False, False, True, True, True, 0, 0, False)
            'Part.SelectionManager.EnableContourSelection = False

            ' 2 
            'Set myFeature = Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, 0.05, 0.05, False, False, False, False, 1.74532925199433E-02, 1.74532925199433E-02, False, False, False, False, True, True, True, 0, 0, False)
            'Part.SelectionManager.EnableContourSelection = False

            ' save as 
            Dim part_name As String = folder & "\" & "Rect Punch" & Convert.ToString(punch_num) & ".SLDPRT"

            rectpunchLst = ResizeArray(rectpunchLst, punch_num)
            rectpunchLst(punch_num - 1) = part_name

            Part.SaveAs3(part_name, 0, 0)

            '*********************************************************************

            ' Close Document

            App.CloseDoc("Rect punch" & Convert.ToString(punch_num))
            punch_num = punch_num + 1


        Next


    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Dim striplayout_outercontour As List(Of List(Of Object))
        Dim striplayout_innercontour As List(Of List(Of Object))
        Dim striplayout_datadict As Dictionary(Of String, Object)

        Using client As New HttpClient()

            ' Set the base URL of the REST API
            Dim apiUrl As String = "http://127.0.0.1:8000/"

            ' Append the endpoint or resource path to the base URL
            'Dim apiEndpoint As String = stepFilePath

            ' Create the full URL by combining the base URL and endpoint
            Dim fullUrl As String = apiUrl & "strip-layout/"
            ' Send a GET request to the API
            Dim response As HttpResponseMessage = client.GetAsync(fullUrl).Result

            ' Check if the request was successful (status code 200)
            If response.IsSuccessStatusCode Then
                ' Read the response content as a string
                Dim responseContent As String = response.Content.ReadAsStringAsync().Result
                Console.WriteLine(responseContent)
                striplayout_datadict = JsonConvert.DeserializeObject(Of Dictionary(Of String, Object))(responseContent)
                striplayout_outercontour = striplayout_datadict("outer contour data").ToObject(Of List(Of List(Of Object)))()
                'Dim striplayout_outercontour As List(Of List(Of Object)) = DirectCast(striplayout_datadict("outer contour data"), List(Of List(Of Object)))
                Console.WriteLine(striplayout_datadict("inner_contours_data"))
                striplayout_innercontour = striplayout_datadict("inner_contours_data").ToObject(Of List(Of List(Of Object)))()
            End If
        End Using



        Dim App As SldWorks
        Dim Part As ModelDoc2
        Dim swPart As PartDoc
        Dim boolstatus As Boolean
        Dim swAssembly As AssemblyDoc
        Dim swInsertedComponent As Component2
        Dim swSelMgr As SelectionMgr
        Dim objFSO As Object
        Dim objFile As Object
        Dim compName As String
        Dim splits As Object
        Dim status As Integer


        'open solid works 
        App = CreateObject("SldWorks.Application")
        App.Visible = True

        App = CreateObject("SldWorks.Application")
        App.Visible = True

        '*********************************************************************

        ' creat new part 

        Part = App.NewPart()

        '*********************************************************************

        If Part IsNot Nothing Then


            ' any two lines from the outer contour 
            ' get it later from step api

            Dim p1 As Double() = {striplayout_outercontour(0)(1) / 1000, striplayout_outercontour(0)(2) / 1000, striplayout_outercontour(0)(3) / 1000}
            Dim p2 As Double() = {striplayout_outercontour(0)(5) / 1000, striplayout_outercontour(0)(6) / 1000, striplayout_outercontour(0)(7) / 1000}
            Dim p3 As Double() = {striplayout_outercontour(1)(1) / 1000, striplayout_outercontour(1)(2) / 1000, striplayout_outercontour(1)(3) / 1000}
            Dim p4 As Double() = {striplayout_outercontour(1)(5) / 1000, striplayout_outercontour(1)(6) / 1000, striplayout_outercontour(1)(7) / 1000}

            'line1 
            Dim line1_x1 As Decimal = striplayout_outercontour(0)(1) / 1000
            Dim line1_y1 As Decimal = striplayout_outercontour(0)(2) / 1000
            Dim line1_z1 As Decimal = striplayout_outercontour(0)(3) / 1000

            Dim line1_x2 As Decimal = striplayout_outercontour(0)(5) / 1000
            Dim line1_y2 As Decimal = striplayout_outercontour(0)(6) / 1000
            Dim line1_z2 As Decimal = striplayout_outercontour(0)(7) / 1000

            'line2
            Dim line2_x1 As Decimal = striplayout_outercontour(1)(1) / 1000
            Dim line2_y1 As Decimal = striplayout_outercontour(1)(2) / 1000
            Dim line2_z1 As Decimal = striplayout_outercontour(1)(3) / 1000

            Dim line2_x2 As Decimal = striplayout_outercontour(1)(5) / 1000
            Dim line2_y2 As Decimal = striplayout_outercontour(1)(6) / 1000
            Dim line2_z2 As Decimal = striplayout_outercontour(1)(7) / 1000       'create FACE_OUTER_BOUND plan
            Dim sketchName As String
            Part.SketchManager.Insert3DSketch(True)

            Part.SketchManager.CreateLine(line1_x1, line1_y1, line1_z1, line1_x2, line1_y2, line1_z2)
            Part.SketchManager.CreateLine(line2_x1, line2_y1, line2_z1, line2_x2, line2_y2, line2_z2)

            Part.SketchManager.Insert3DSketch(True)

            'Part.ClearSelection2(True)
            'Part.SketchManager.InsertSketch(True)
            Part.ClearSelection2(True)



            If (p1(0) <> p2(0) Or p1(2) <> p2(2)) And (p1(0) <> p3(0) Or p1(2) <> p3(2)) And (p2(0) <> p3(0) Or p2(2) <> p3(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p1(0), p1(1), p1(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p2(0), p2(1), p2(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p3(0), p3(1), p3(2), True, 2, Nothing, 0)




            ElseIf (p1(0) <> p2(0) Or p1(2) <> p2(2)) And (p1(0) <> p4(0) Or p1(2) <> p4(2)) And (p2(0) <> p4(0) Or p2(2) <> p4(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p1(0), p1(1), p1(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p2(0), p2(1), p2(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p4(0), p4(1), p4(2), True, 2, Nothing, 0)



            ElseIf (p3(0) <> p2(0) Or p3(2) <> p2(2)) And (p3(0) <> p4(0) Or p3(2) <> p4(2)) And (p2(0) <> p4(0) Or p2(2) <> p4(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p3(0), p3(1), p3(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p2(0), p2(1), p2(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p4(0), p4(1), p4(2), True, 2, Nothing, 0)



            ElseIf (p3(0) <> p1(0) Or p3(2) <> p1(2)) And (p3(0) <> p4(0) Or p3(2) <> p4(2)) And (p1(0) <> p4(0) Or p1(2) <> p4(2)) Then
                Part.Extension.SelectByID2("", "SketchPoint", p3(0), p3(1), p3(2), True, 0, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p1(0), p1(1), p1(2), True, 1, Nothing, 0)
                Part.Extension.SelectByID2("", "SketchPoint", p4(0), p4(1), p4(2), True, 2, Nothing, 0)

            End If

            'Part.Extension.SelectByID2("", "SketchPoint", line1_x2, line1_y2, line1_z2, True, 0, Nothing, 0)
            'Part.Extension.SelectByID2("", "SketchPoint", line2_x2, line2_y2, line2_z2, True, 1, Nothing, 0)
            'Part.Extension.SelectByID2("", "SketchPoint", line2_x1, line2_y1, line2_z1, True, 2, Nothing, 0)

            'Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)
            Part.FeatureManager.InsertRefPlane(4, 0, 4, 0, 4, 0)
            ' plane rename 
            Part.Extension.SelectByID2("Plane1", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B plane")
            Part.ClearSelection2(True)

            'hide sketch 
            Part.Extension.SelectByID2("3DSketch1", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.BlankSketch()

            '*********************************************************************


            'insert 3d sketch for outer boundry
            Dim outer_bound_thickness = 0.006


            Part.SketchManager.Insert3DSketch(True)

            For Each entity In striplayout_outercontour
                Console.WriteLine(entity(8))
                If entity(8) = "LINE" Then
                    Part.SketchManager.CreateLine(entity(1) / 1000, entity(2) / 1000, entity(3) / 1000, entity(5) / 1000, entity(6) / 1000, entity(7) / 1000)
                ElseIf entity(8) = "CIRCLE" Then
                    Part.SketchManager.CreateTangentArc(entity(1) / 1000, entity(2) / 1000, entity(3) / 1000, entity(5) / 1000, entity(6) / 1000, entity(7) / 1000, 1)
                End If
            Next


            ' Rename for outer bound sketch 

            Part.Extension.SelectByID2("3DSketch2", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, "O.B Sketch")

            'extrude for outer bound 
            Part.Extension.SelectByID2("O.B Sketch", "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
            Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0) ' mesh 3aref leeh 16 w leeh true 
            Part.FeatureManager.FeatureExtrusion2(True, False, True, 0, 0, outer_bound_thickness, outer_bound_thickness, False, False, False, False, 0.0174532925199433, 0.0174532925199433, False, False, False, False, True, True, True, 0, 0, False)
            Part.SelectionManager.EnableContourSelection = False

            '*********************************************************************

            ' inner bound 

            Console.WriteLine("-------------------------")
            'Console.WriteLine(striplayout_datadict("inner_contours_data")(0)(0)(8))
            Dim i As Integer = 0
            Dim j As Integer = 0
            Dim c As Integer = 0
            For Each facebound In striplayout_datadict("inner_contours_data")
                If striplayout_datadict("inner_contours_data")(c)(0)(8) = "LINE" Then
                    Part.ClearSelection2(True)
                    Part.SketchManager.Insert3DSketch(True)

                    ' Select the newly created 3D sketch
                    Part.Extension.SelectByID2("3DSketch" & i + 3, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)

                    ' Rename the selected 3D sketch
                    sketchName = "inner contour 3d" & i + 1
                    Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, sketchName)

                ElseIf striplayout_datadict("inner_contours_data")(c)(0)(8) = "CIRCLE" Then
                    Part.ClearSelection2(True)

                    Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, False, 0, Nothing, 0)
                    Part.SketchManager.InsertSketch(True)
                    Part.Extension.SelectByID2("Sketch" & j + 1, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)

                    ' Rename the selected 3D sketch
                    sketchName = "inner contour 2d" & j + 1
                    Part.SelectedFeatureProperties(0, 0, 0, 0, 0, 0, 0, 1, 0, sketchName)


                End If

                For Each entity In facebound
                    Console.WriteLine("entity:")
                    Console.WriteLine(entity)
                    If entity(8) = "LINE" Then
                        Part.SketchManager.CreateLine(entity(1) / 1000, entity(2) / 1000, entity(3) / 1000, entity(5) / 1000, entity(6) / 1000, entity(7) / 1000)

                    ElseIf entity(8) = "CIRCLE" Then
                        Console.WriteLine("entity 9:" & entity(9).ToString() & " entity 11:" & entity(11).ToString() & " radius" & entity(12).ToString())
                        Part.SketchManager.CreateCircleByRadius(entity(9) / 1000, -entity(11) / 1000, 0, entity(12) / 1000)
                    End If
                Next


                If striplayout_datadict("inner_contours_data")(c)(0)(8) = "LINE" Then
                    ' Extrude cut for the inner bound in the 3D sketch
                    Part.Extension.SelectByID2(sketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
                    Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0)
                    Part.FeatureManager.FeatureCut4(True, False, True, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)
                    i = i + 1

                ElseIf striplayout_datadict("inner_contours_data")(c)(0)(8) = "CIRCLE" Then
                    Part.Extension.SelectByID2(sketchName, "SKETCH", 0, 0, 0, False, 0, Nothing, 0)
                    Part.Extension.SelectByID2("O.B plane", "PLANE", 0, 0, 0, True, 16, Nothing, 0)

                    ' Extrude cut holes inner bound 
                    Part.FeatureManager.FeatureCut4(True, False, False, 1, 1, 0, 0, False, False, False, False, 0, 0, False, False, False, False, False, True, True, True, True, False, 0, 0, False, False)
                    j = j + 1

                End If

                c = c + 1
            Next

            Part.ShowNamedView2("*Isometric", 7)
            Part.ViewZoomtofit2()


            Part.SaveAs3(partFilePath, 0, 0)

        End If



    End Sub
End Class
