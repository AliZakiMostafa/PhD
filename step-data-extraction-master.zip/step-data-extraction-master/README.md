# step-data-extraction

This project is used to extract data from solidworks part in a step format for analysis or for any other application

Created By 
Abdalla Omar
