import os
import numpy as np
import re


def get_inside_hashes(line):
    pattern = r"#(\d+)"
    matches = re.findall(pattern, line)
    numbers = [int(match) for match in matches]
    numbers = numbers[1:]
    return numbers


def data_extract(line):
    global faces
    global found_face
    global bound_face
    global face
    hashes = get_inside_hashes(line)

    if hashes:
        for hash in hashes:
            new_line = fileArray[hash - 1]
            print(new_line)

            if "ADVANCED_FACE" in new_line:
                print("Found advanced face!!!!!!!!!!")
                found_face = True
                face = new_line
                print(face)
                print("*" * 150)
                output_data.append("*" * 150)
            if "FACE_BOUND" in new_line:
                print("It has a face_bounnnnnnnd !!!!!!! ")
                faces.append(face)

            output_data.append(new_line)

            data_extract(new_line)


def extract_step(step_file_path):
    with open(step_file_path, "r") as file:
        fileArray = np.array(file.readlines())

    modifiedArray = np.array([], dtype=int)
    for line in fileArray:
        if "#" in line:
            modifiedArray = np.append(modifiedArray, line)

    fileArray = modifiedArray.copy()

    advancedFacesArray = np.array([], dtype=int)
    drawingFacesArray = np.array([], dtype=int)

    for line in fileArray:
        if "ADVANCED_FACE" in line:
            advancedFacesArray = np.append(advancedFacesArray, line.strip())

    closedShellArray = np.array([], dtype=int)
    for line in fileArray:
        if "CLOSED_SHELL" in line:
            closedShellArray = np.append(closedShellArray, line.strip())

    output_data = []
    for line in closedShellArray:
        print(line)
        output_data.append(line)
        print("-" * 150)
        data_extract(line)

    with open("data_extracted.txt", "w") as file:
        for line in output_data:
            file.write(line + "\n")
