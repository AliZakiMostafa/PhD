the purpose of the application is to get a step file as an input 
and return the outer facebound 
the other facebounds