import math


class Entity:
    def __init__(self, id, x, y, entity_type):
        self.id = id
        self.x = x
        self.y = y
        self.entity_type = entity_type


class Circle(Entity):
    def __init__(self, id, x, y, entity_type, center_point, radius):
        super().__init__(id, x, y, entity_type)

        self.center_point = list(center_point)
        self.radius = radius

    def adjust_x(self,add_value):
        # print(f"centroid:{self.center_point}")
        
        self.center_point[0]+=add_value

class Line(Entity):
    def __init__(self, id, x, y, entity_type):
        x = list(x)
        y = list(y)
        super().__init__(id, x, y, entity_type)
    def get_length(self):
        l = math.dist(self.x,self.y)
        return l
    def adjust_x(self,add_value):
        print(f"x value:{self.x}")
        print(f"y value:{self.y}")
        
        self.x[0]+= add_value
        self.y[0]+=add_value
        
        
        
        
class Contour:
    def __init__(self, id, lst_of_entities, contour_type):
        self.id = id
        self.lst_of_entities = lst_of_entities
        self.contour_type = contour_type
        self.get_centroid()
    def get_far_point(self):
        far_point = None
        far_dist = 0
        points = []
        for e in self.lst_of_entities:
            points.append(e.x)
            points.append(e.y)

        xt = 0
        yt = 0
        zt = 0

        for p in points:
            xt += p[0]
            yt += p[1]
            zt += p[2]

        n = len(points)

        centroid = [xt / n, yt / n, zt / n]
        for p in points:
            d = math.sqrt(
                (p[0] - centroid[0]) ** 2
                + (p[1] - centroid[1]) ** 2
                + (p[2] - centroid[2]) ** 2
            )
            if far_dist < d:
                far_dist = d
                far_point = p

        return far_point, far_dist, centroid

    def get_perimeter(self):
        perimeter =0 
        for entity in self.lst_of_entities:
            if entity.entity_type == 'LINE':
                perimeter+=entity.get_length()
            elif entity.entity_type == 'CIRCLE':
                perimeter = 2*math.pi*entity.radius
        return perimeter
    
    
    def get_centroid(self):
        _,_,self.centroid = self.get_far_point()
        return self.centroid
    def calculate_shearing_force(self):
        # this fn to calculate punch shearing force 
        # Cs is a material cofficient can be get from engineering materials handbook
        # l is the shearing length # can be calculated from punch geometery
        # t sheet thickness
        # T tensile strength of material 
        Cs = 0.22 # this is for steel 37
        T = 435 # This is tensile strength for steel 37 calculated by taking an avg of 360 - 510 its in MPa
        # assuming material thickness is 6 mm for now 
        t = 6
        
        #calculating length of shearing for the contour  which is equal to the perimeter
        l = self.get_perimeter()
        
        Fs = Cs*l*t*T
        
        return Fs
    
    
        
class Part:
    def __init__(self,length,width,thickness,outer_contour,inner_contours):
        self.length = length 
        self.thickness = thickness
        self.width = width
        self.outer_contour_lst = outer_contour
        self.inner_contours_lst = inner_contours
        self.inner_contours = self.create_inner_contours()
        self.outer_contour = self.create_outer_contour()
        
        
    def create_inner_contours(self):
        lst_of_objs = []
        for entity in self.inner_contours_lst:
            if entity[8] == "CIRCLE":
                id = entity[14]
                x = (entity[1], entity[2], entity[3])
                y = (entity[5], entity[6], entity[7])
                center_point = (entity[9], entity[10], entity[11])
                radius = entity[12]
                circle = Circle(id, x, y, "CIRCLE", center_point, radius)
                lst_of_objs.append(circle)

            elif entity[8] == "LINE":
                id = entity[10]
                x = (entity[1], entity[2], entity[3])
                y = (entity[5], entity[6], entity[7])
                line = Line(id, x, y, "LINE")
                lst_of_objs.append(line)

        contour_nums = []
        for entity in lst_of_objs:
            contour_nums.append(entity.id)

        contour_nums = set(contour_nums)

        lst_of_contours = []
        for id in contour_nums:
            lst_of_entities = []
            for obj in lst_of_objs:
                if obj.id == id:
                    lst_of_entities.append(obj)
                    contour_type = obj.entity_type
            contour = Contour(id, lst_of_entities, contour_type)
            lst_of_contours.append(contour)
        return lst_of_contours        
        
    def create_outer_contour(self):
        lst_of_objs = []
        for entity in self.outer_contour_lst:
            if entity[8] == "CIRCLE":
                x = (entity[1], entity[2], entity[3])
                y = (entity[5], entity[6], entity[7])
                center_point = (entity[9], entity[10], entity[11])
                radius = entity[12]
                circle = Circle(100, x, y, "CIRCLE", center_point, radius)
                lst_of_objs.append(circle)

            elif entity[8] == "LINE":
                x = (entity[1], entity[2], entity[3])
                y = (entity[5], entity[6], entity[7])
                line = Line(100, x, y, "LINE")
                lst_of_objs.append(line)

        outer_contour = Contour(100,lst_of_objs,"outer_contour")
        return outer_contour





class Group:
    def __init__(self, id, lst_of_contours):
        self.id = id
        self.lst_of_contours = lst_of_contours

    def check_collide(self, added_contour):
        # get the farthest distance for the contour i want to add to the group
        c1, cc1, centroid1 = added_contour.get_far_point()
        collide_mark = False
        # loop over each contour in the group and check collide with the added contour
        for contour in self.lst_of_contours:
            # get each contour farthest distance
            c2, cc2, centroid2 = contour.get_far_point()

            # get the distance between the two farthest points for both contours
            dist_c1_c2 = math.sqrt(
                (centroid1[0] - centroid2[0]) ** 2 + (centroid1[1] - centroid2[1]) ** 2 + (centroid1[2] - centroid2[2]) ** 2
            )
            r = cc1 * 1.5 + cc2 * 1.5
            # print(f"distance between two centeroids:{round(dist_c1_c2,2)}, sum of farthest dist {round(r,2)} ")
            if dist_c1_c2 > r:
                pass
            elif dist_c1_c2 < r:
                collide_mark = True
        return collide_mark

    def add_contour(self, contour):
        self.lst_of_contours.append(contour)
        return True


    def get_n_punches(self):
        # this function to return the number of punches in a group
        n_punches = len(self.lst_of_contours)
        return n_punches        
        
class Strip:
    def __init__(self, id, lst_of_groups,part_length,part_width,part_thickness):
        self.lst_of_groups = lst_of_groups
        self.id = id
        self.part_length=part_length
        self.part_width= part_width
        self.part_thickness= part_thickness
    def add_group(self, group):
        self.lst_of_groups.append(group)
        return True

    def adjust_punches_location(self):
        punches = self.get_punches()
        n_stages = len(self.lst_of_groups)
        new_group = []
        print(f"data: dim {self.part_length},{self.part_thickness}")
        new_punches = []
        for n_stage,group in enumerate(self.lst_of_groups):
            print(f"n stage:{n_stage}")
            for punch in group.lst_of_contours:
                print(f"punch centroid before{punch.centroid[0]}")
                increase_value = self.part_length*(n_stage)+ n_stage*1.5*self.part_thickness
                punch.centroid[0] += increase_value
                print(f"punch centroid after{punch.centroid[0]}")
                for entity in punch.lst_of_entities:
                    entity.adjust_x(increase_value)
                    
                new_punches.append(punch)
        return new_punches

    def get_total_n_punches(self):
        #this func to get total number of punches in strip layout
        n_punches = 0
        for group in self.lst_of_groups:
            n_punches+=group.get_n_punches()
        return n_punches
    

    def calculate_stage_number_factor(self):
        #this function to calculate the stage number factor fn
        n_stage = len(self.lst_of_groups)
        n_punches = self.get_total_n_punches()
        print(n_stage,n_punches)
        fn = 100-90*(n_stage-2)/(n_punches-2)
        return fn
    
    
    def get_strip_length(self):
        n_stages = len(self.lst_of_groups)
        
        l = n_stages * self.part_length + 1.5*self.part_thickness*(n_stages-1)
        return l 
    
    def get_strip_width(self):
        return self.part_width 
    
    def calculate_centroid(self,points):
        total_x = 0
        total_y = 0
        num_points = len(points)

        for point in points:
            total_x += point[0]
            total_y += point[2]

        centroid_x = total_x / num_points
        centroid_y = total_y / num_points

        return (centroid_x, centroid_y)

    def get_strip_origin(self):
        punches = self.get_punches()
        points = []
        for punch in punches:
            points.append(punch.get_centroid())
        
        origin = self.calculate_centroid(points)
        return origin 
    
    def get_punches(self):
        punches = []
        for group in self.lst_of_groups:
            punches += group.lst_of_contours
            
        return punches
    
    def get_punch_dist_from_origin(self,punch):
        origin = self.get_strip_origin()
        punch_centroid = punch.get_centroid()
        
        xi = punch_centroid[0]-origin[0]
        yi = punch_centroid[2]-origin[1]
        
        return [xi,yi]
    def get_punch_force_comp(self,punch):
        # this function to calculate force component shearing force * dist from origin
        x_comp = punch.calculate_shearing_force()*self.get_punch_dist_from_origin(punch)[0]
        y_comp = punch.calculate_shearing_force()*self.get_punch_dist_from_origin(punch)[1]
        
        m = [x_comp,y_comp]
        return m
    
    def calculate_max_deviation(self):
        # getting max deviation as calculated from the paper 
        # checked manually and its correct 
        
        dmax= math.sqrt((self.get_strip_length()/4)**2+(self.get_strip_width()/4)**2)
        return dmax
    
    def get_total_punches_force(self):
        F = 0
        for punch in self.get_punches():
            F+=punch.calculate_shearing_force()
        return F
    
    def get_punches_deviation(self):
        punches = self.get_punches()
        F = self.get_total_punches_force()
        xcomp = 0
        ycomp = 0
        for punch in punches:
            xcomp+= self.get_punch_force_comp(punch)[0]
            ycomp+= self.get_punch_force_comp(punch)[1]
        
        xbar = xcomp/F
        ybar = ycomp/F
        
        #deviation equation
        d = math.sqrt(xbar**2+ybar**2)
        
        return d
   
    def check_rules(self):
        #rule1 :
        # the two largest holes for piloting
        # prefered operation sequence 
        # 1. piercing 
        # 2. notching
        # 3. blanking or parting off
        
        pass
    
        
    def calculate_moment_balancing_factor(self):
        # calculate distance of each punch in x,y from the strip origin
        dmax = self.calculate_max_deviation()
        d = self.get_punches_deviation()
        
        moment_balancing_factor = 100 * (1-0.9*d/dmax)
        
        return moment_balancing_factor
    
    
    
    



def create_initial_solution(lst_of_contours,part_length,part_width,part_thickness):
    # first rule
    lst_of_groups = []
    # group all circles together,
    idx = 0
    added_to_groups = 0
    lst_of_contours_added =[]
    while True:
        group = Group(idx, [])
        for contour in lst_of_contours:
            if contour.contour_type == "CIRCLE":
                # print("circle")
                if not group.check_collide(contour) and contour.id not in lst_of_contours_added:
                    group.add_contour(contour)
                    # print(f"contour added to group:{group.id}")
                    added_to_groups += 1
                    lst_of_contours_added.append(contour.id)

        for contour in lst_of_contours:
            if contour.contour_type == "LINE":
                # print("LINE")
                if not group.check_collide(contour) and contour.id not in lst_of_contours_added:
                    group.add_contour(contour)
                    # print(f"contour added to group:{group.id}")
                    added_to_groups += 1
                    lst_of_contours_added.append(contour.id)

        lst_of_groups.append(group)
        idx += 1
        if added_to_groups >= len(lst_of_contours):
            break

    strip = Strip(0, lst_of_groups,part_length,part_width,part_thickness)
    return strip
