import os
import numpy as np
import re

import copy


def get_file_array(step_file_path):
    with open(step_file_path, "r") as file:
        fileArray = np.array(file.readlines())

    modifiedArray = np.array([], dtype=int)
    for line in fileArray:
        if "#" in line:
            modifiedArray = np.append(modifiedArray, line)

    fileArray = modifiedArray.copy()
    return fileArray


def get_specific_element(fileArray, element):
    elementArray = np.array([], dtype=int)

    for line in fileArray:
        if element in line:
            elementArray = np.append(elementArray, line.strip())
    return elementArray


def get_inside_hashes(line):
    pattern = r"#(\d+)"
    matches = re.findall(pattern, line)
    numbers = [int(match) for match in matches]
    numbers = numbers[1:]
    return numbers


def get_line_by_hash(step_array, hash_num):
    hash_num = "#" + str(hash_num)
    for line in step_array:
        if line.startswith(hash_num):
            return line


def get_element_name(line):
    match = re.search(r"=(\s*)(\w+)", line)
    if match:
        word_after_equal = match.group(2)
        return word_after_equal
    else:
        return False


def get_circle_radius(line):
    match = re.search(r"\(([^,]+),\s*([^,]+),\s*([^,]+)\)", line)
    if match:
        third_element = match.group(3)
        return round(float(third_element), 2)
    else:
        return False


def get_specific_element(fileArray, element):
    elementArray = np.array([], dtype=int)

    for line in fileArray:
        if element in line:
            elementArray = np.append(elementArray, line.strip())
    return elementArray


def data_extract(fileArray, line, output_data):
    hashes = get_inside_hashes(line)
    if hashes:
        for hash1 in hashes:
            new_line = fileArray[hash1 - 1]
            output_data.append(new_line)
            data_extract(fileArray, new_line, output_data)
    return output_data


def get_extracted_data(fileArray, required_array):
    output_data = []
    for line in required_array:
        output_data.append(line)
        output_data = data_extract(fileArray, line, output_data)

    return output_data


def get_numbers_from_string(string):
    start = string.find("(")
    end = string.find(")")
    parenthesis = string[start : end + 1]
    return parenthesis


def extract_numbers_from_string(string):
    new_string = get_numbers_from_string(string)[1:]
    new_string = get_numbers_from_string(new_string)
    numbers = new_string[1:-1].split(",")
    numbers = [float(num) for num in numbers]
    return [round(num) for num in numbers]


def get_circle_center_point(step_array, circle):
    circle_data = get_extracted_data(step_array, [circle])
    center_point_string = get_specific_element(circle_data, "CARTESIAN_POINT")
    points = extract_numbers_from_string(center_point_string[0])
    return points


def identify_major_face(step_array):
    advanced_face_array = get_specific_element(step_array, "ADVANCED_FACE")
    major_face = None
    max_hashes = 0

    for face in advanced_face_array:
        numbers = get_inside_hashes(face)
        if len(numbers) > max_hashes and "T." in face:
            max_hashes = len(numbers)
            major_face = face

    return major_face


def get_thickness_from_advanced_face(step_array):
    advanced_face_array = get_specific_element(step_array, "ADVANCED_FACE")

    # Initialize a dictionary to store the face and its corresponding number of hashes
    face_hash_counts = {}

    for face in advanced_face_array:
        numbers = get_inside_hashes(face)
        face_hash_counts[face] = len(numbers)

    # Sort the faces based on the number of hashes in descending order
    sorted_faces = sorted(face_hash_counts, key=face_hash_counts.get, reverse=True)

    # Get the two maximum faces
    max_faces = sorted_faces[:2]

    return max_faces



def line_first(item):
    if 'LINE' in item:
        return 0
    else:
        return 1



def extract_outer_face_data(step_array, face):
    print(face)
    output_array = get_extracted_data(step_array, [face])
    outer_boundary = get_specific_element(output_array, "FACE_OUTER_BOUND")
    outer_boundary_data = get_extracted_data(step_array, outer_boundary)
    edge_curve_outer_bond_data = get_specific_element(outer_boundary_data, "EDGE_CURVE")
    face_lst = []
    for edge in edge_curve_outer_bond_data:
        edge_data = get_inside_hashes(edge)
        edge_lst = []
        for e in edge_data:
            e_line = get_line_by_hash(step_array, e)
            element_name = get_element_name(e_line)
            edge_lst.append(element_name)
            if element_name == "LINE":
                pass
            if element_name == "CIRCLE":
                # get center point and radius
                center_point = get_circle_center_point(step_array, e_line)
                edge_lst += center_point
                radius = get_circle_radius(e_line)
                edge_lst.append(radius)

            if element_name == "VERTEX_POINT":
                # get cartisean in this element
                # store it in the lst
                element_data = get_extracted_data(step_array, [e_line])
                # print(element_data)
                cart_line_array = get_specific_element(element_data, "CARTESIAN_POINT ")
                for cart in cart_line_array:
                    points = extract_numbers_from_string(cart)
                    edge_lst += points

        face_lst.append(edge_lst)



    sorted_data = sorted(face_lst, key=line_first)

    return sorted_data


def extract_inner_face_data(step_array, face,idx):
    print(face)
    output_array = get_extracted_data(step_array, [face])
    outer_boundary = get_specific_element(output_array, "FACE_BOUND")
    outer_boundary_data = get_extracted_data(step_array, outer_boundary)
    edge_curve_outer_bond_data = get_specific_element(outer_boundary_data, "EDGE_CURVE")
    print(outer_boundary)
    face_lst = []
    for edge in edge_curve_outer_bond_data:
        edge_data = get_inside_hashes(edge)
        edge_lst = []
        for e in edge_data:

            e_line = get_line_by_hash(step_array, e)
            element_name = get_element_name(e_line)
            edge_lst.append(element_name)
            if element_name == "LINE":
                pass
            if element_name == "CIRCLE":
                # get center point and radius
                center_point = get_circle_center_point(step_array, e_line)
                edge_lst += center_point
                radius = get_circle_radius(e_line)
                edge_lst.append(radius)

            if element_name == "VERTEX_POINT":
                # get cartisean in this element
                # store it in the lst
                element_data = get_extracted_data(step_array, [e_line])
                # print(element_data)
                cart_line_array = get_specific_element(element_data, "CARTESIAN_POINT")
                for cart in cart_line_array:
                    points = extract_numbers_from_string(cart)
                    edge_lst += points
        edge_lst.append("contour_id")
        edge_lst.append(idx)

        face_lst.append(edge_lst)

    return face_lst


# function to return data for inner contour
def get_inner_contours_data(step_array, major_face):
    inner_boundaries = get_specific_element(step_array, "FACE_BOUND")
    contours_data = []
    for i,contour in enumerate(inner_boundaries):
        contours_data.append(extract_inner_face_data(step_array, contour,i))

    return contours_data

# processing punches
def process_extrude_punches(inner_contours,outer_contours):
    length,length_entity,width,width_entity = get_length_width(outer_contours)
    outer_punch1, outer_punch2 = get_outer_punches(outer_contours,length_entity,width_entity,6)
    punches_contour = []
    pp1= []
    for i,p in enumerate(outer_punch1):
        print(i,p)
        if i == len(outer_punch1)-1:
            entity = ["VERTEX_POINT",p[0],p[1],p[2],"VERTEX_POINT",outer_punch1[0][0],outer_punch1[0][1],outer_punch1[0][2],"LINE"]
        else:
            entity = ["VERTEX_POINT",p[0],p[1],p[2],"VERTEX_POINT",outer_punch1[i+1][0],outer_punch1[i+1][1],outer_punch1[i+1][2],"LINE"]
        pp1.append(entity)

    pp2= []
    for i,p in enumerate(outer_punch2):
        if i == len(outer_punch2)-1:
            entity = ["VERTEX_POINT",p[0],p[1],p[2],"VERTEX_POINT",outer_punch2[0][0],outer_punch2[0][1],outer_punch2[0][2],"LINE"]
        else:
            entity = ["VERTEX_POINT",p[0],p[1],p[2],"VERTEX_POINT",outer_punch2[i+1][0],outer_punch2[i+1][1],outer_punch2[i+1][2],"LINE"]
        pp2.append(entity)


    punches_contour.append(pp1)
    punches_contour.append(pp2)
    return punches_contour

def process_punch_data(inner_contours,outer_contours):
    #this function to process circular punches 
    if len(inner_contours) == 0:
        return []
    punches_contour = []    
    punch_length = 50
    cap1 = 3
    cap2 = 2
    clearence=5
    cap0_thickness = 0.1*punch_length
    cap1_thickness =  0.4*punch_length
    cap2_thickness = 0.5*punch_length
    for i,contour in enumerate(inner_contours):
        if len(contour)>0:
            print(f"len:{len(contour)},contour:{contour}")
            for j,entity in enumerate(contour):
                if entity[8] == 'CIRCLE':
                    center_point = (entity[9],entity[10]+clearence,entity[11])
                    radius = entity[12]
                    cap0 = radius + cap1 + cap2
                    #start creating punch entities
                    entity1 = ['VERTEX_POINT', center_point[0], center_point[1], center_point[2], 'VERTEX_POINT', center_point[0], center_point[1]+punch_length, center_point[2], 'LINE',radius]
                    entity2 = ['VERTEX_POINT', center_point[0], center_point[1]+punch_length, center_point[2], 'VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length, 0, 'LINE']
                    entity3 = ['VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length, center_point[2], 'VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length-cap0_thickness, 0, 'LINE']
                    entity4 = ['VERTEX_POINT', center_point[0]+cap0, center_point[1]+punch_length-cap0_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness, 0, 'LINE']
                    entity5 = ['VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness-cap1_thickness, 0, 'LINE']
                    entity6 = ['VERTEX_POINT', center_point[0]+cap0-cap1, center_point[1]+punch_length-cap0_thickness-cap1_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness, 0, 'LINE']
                    entity7 = ['VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness, center_point[2], 'VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness-cap2_thickness, 0, 'LINE']
                    entity8 = ['VERTEX_POINT', center_point[0]+cap0-cap1-cap2, center_point[1]+punch_length-cap0_thickness-cap1_thickness-cap2_thickness, center_point[2], 'VERTEX_POINT', center_point[0], center_point[1], 0, 'LINE']

                    punches_contour.append([
                        entity1,entity2,entity3,entity4,entity5,entity6,entity7,entity8
                    ])

    length,length_entity,width,width_entity = get_length_width(outer_contours)
    outer_punch1, outer_punch2 = get_outer_punches(outer_contours,length_entity,width_entity,6)
    
    pp1= []
    for i,p in enumerate(outer_punch1):
        print(i,p)
        if i == len(outer_punch1)-1:
            entity = ["VERTEX_POINT",p[0],p[2],p[1],"VERTEX_POINT",outer_punch1[0][0],outer_punch1[0][2],outer_punch1[0][1],"LINE"]
        else:
            entity = ["VERTEX_POINT",p[0],p[2],p[1],"VERTEX_POINT",outer_punch1[i+1][0],outer_punch1[i+1][2],outer_punch1[i+1][1],"LINE"]
        pp1.append(entity)

    pp2= []
    for i,p in enumerate(outer_punch2):
        if i == len(outer_punch2)-1:
            entity = ["VERTEX_POINT",p[0],p[2],p[1],"VERTEX_POINT",outer_punch2[0][0],outer_punch2[0][2],outer_punch2[0][1],"LINE"]
        else:
            entity = ["VERTEX_POINT",p[0],p[2],p[1],"VERTEX_POINT",outer_punch2[i+1][0],outer_punch2[i+1][2],outer_punch2[i+1][1],"LINE"]
        pp2.append(entity)

    # punches_contour.append(pp1)
    # punches_contour.append(pp2)

    
    print(f"p contours:{punches_contour}")
    with open("punches_contour1.json", "w") as fi:
        fi.write(str(punches_contour))
    return punches_contour

    

def process_rect_punch_data(inner_contours,outer_contours):
   
    clearance = 5
    rect_punches =[]
    for contour in inner_contours:
        new_contour = []
        for entity in contour:
            if entity[8]=='CIRCLE':
                continue
            entity[2]+=clearance
            entity[6]+=clearance
            new_contour.append(entity)
        if len(new_contour)!=0:
            rect_punches.append(new_contour)
    export_contours(inner_contours,outer_contours)
    with open("punches_contour2.json", "w") as fi:
        fi.write(str(rect_punches))
    return rect_punches


def export_contours(inner_contours,outer_contours):
    with open("contours.json", "w") as fi:
        fi.write(str(inner_contours))
        fi.write(str(outer_contours))



def get_cirle_center(inner_contours):
    center_points=[]
    if len(inner_contours) == 0:
        return []
    for i,contour in enumerate(inner_contours):
        if len(contour)>0:
            print(f"len:{len(contour)},contour:{contour}")
            for j,entity in enumerate(contour):
                if entity[8] == 'CIRCLE':
                    center_point = (entity[9],entity[10],entity[11])
                    center_points.append([entity[9],entity[10],entity[11]])
    print(f"center points:{center_points}")
    return center_points


def process_die_data(inner_contours):
    if len(inner_contours) == 0:
        return []
    punches_contour = []    
    die_length= 15
    clearance = 0.25
    t=6
    offset= 5 + t 
    die_base = 5
    for i,contour in enumerate(inner_contours):
        if len(contour)>0:
            print(f"len:{len(contour)},contour:{contour}")
            for j,entity in enumerate(contour):
                if entity[8] == 'CIRCLE': # this case when the contour is one circle
                    center_point = (entity[9],entity[10],entity[11])
                    radius = entity[12]
                    #start creating punch entities
                    entity1 = ['VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset, center_point[2], 'VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset-die_base, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity2 = ['VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset-die_base, center_point[2], 'VERTEX_POINT',center_point[0]+radius+1+clearance, center_point[1]-offset-die_base-die_length, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity3 = ['VERTEX_POINT', center_point[0]+radius+1+clearance, center_point[1]-offset-die_base-die_length, center_point[2], 'VERTEX_POINT', center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity4 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length, center_point[2], 'VERTEX_POINT',  center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length+4.1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity5 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1, center_point[1]-offset-die_base-die_length+4.1, center_point[2], 'VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity6 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity7 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base-die_length+4.1+1, center_point[2], 'VERTEX_POINT',center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base+4.1+1, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]
                    entity8 = ['VERTEX_POINT', center_point[0]+radius+1+clearance+7.1-1-4, center_point[1]-offset-die_base+4.1+1, center_point[2], 'VERTEX_POINT', center_point[0]+radius+clearance, center_point[1]-offset, center_point[2], 'LINE',center_point[0],center_point[1],center_point[2]]

                    punches_contour.append([
                        entity1,entity2,entity3,entity4,entity5,entity6,entity7,entity8
                    ])
    print(f"die contours:{punches_contour}")
    return punches_contour


def process_irregular_die_data(inner_contours):
    if len(inner_contours) == 0:
        return []
    punches_contour = []    
    added_ids = []
    for i,contour in enumerate(inner_contours):
        if len(contour)>0:
            print(f"len:{len(contour)},contour:{contour}")
            for j,entity in enumerate(contour):
                if entity[8] == 'LINE': # This case when the contour is consists of lines only
                    if entity[10] in added_ids:
                        pass
                    else:
                        added_ids.append(entity[10])
                        punches_contour.append(contour)
    print(f"die contours:{punches_contour}")
    return punches_contour



import math
def get_dist(p1,p2):
    l = math.dist(p1,p2)
    return l 
def get_length_width(outer_contour):
    print(f"len entities:{len(outer_contour[0])}")

    if len(outer_contour[0]) <10:
        for entity in outer_contour:
            print(entity)
            p1 = (entity[1],entity[2],entity[3])
            p2 = (entity[5],entity[6],entity[7])
            dist = get_dist(p1,p2)
            print(dist)
            entity.append("dist")
            entity.append(dist)
            

    width = 0
    width_entity = None
    length = 0
    length_entity = None
    print(f"outer contourrrrrrrrrrrrr:{outer_contour}")
    for entity in outer_contour:
        if entity[8]=='LINE':
            change_in_x = entity[5] -entity[1]
            if length < change_in_x:
                print(f"length found:{entity}")
                length = entity[10]
                length_entity = entity
    
    for entity in outer_contour:
        if entity[8]=='LINE':
            change_in_y = entity[7] - entity[3]
            print(f"change in y:{change_in_y}")
            if width < change_in_y: #checkingg if entity is equal to length entity not the length itself in mm
                print(f"width found:{entity}")
                width = entity[10]
                width_entity = entity


    if width_entity == None:
        width_entity = length_entity
        width = length
    print(f"length:{length}, length entity:{length_entity}\n width:{width}, width_entity:{width_entity}")
    return length,length_entity,width,width_entity

def find_middle_point(line_data):
    x1, y1, z1, x2, y2, z2 = line_data  # Assuming the line data format is consistent

    middle_x = (x1 + x2) / 2
    middle_y = (y1 + y2) / 2
    middle_z = (z1 + z2) / 2

    return [middle_x, middle_y, middle_z]

def get_outer_punches2(outer_contour,length_line,width_line,t):
    '''
    This fn to calculate the outer punches points 
    it takes the outer_contour, length line, width line, and thickness as an input params

    '''
    
    #getting the points of the length
    lp1 = [length_line[1],length_line[2],length_line[3]]
    lp2 = [length_line[5],length_line[6],length_line[7]]
    

    #getting the points of the width, note that if the part is rectangular then its length and width are the same
    wp1 = [width_line[1],width_line[2],width_line[3]]
    wp2 = [width_line[5],width_line[6],width_line[7]]
    


    length = get_dist(lp1,lp2)
    width = get_dist(wp1,wp2)

    print(f"length and width :{length}, {width}")
    lp1_mirrored = copy.deepcopy(lp1)

    #shifting the first point by 2* length and t 
    lp1_mirrored[0]+=2*length+t

    #new line == to this new data
    line_data = [lp1[0],lp1[1],lp1[2],lp1_mirrored[0],lp1_mirrored[1],lp1_mirrored[2]]

    punch_middle_point = find_middle_point(line_data)
    punch_middle_point[0] -= t/2
    print(f"length:{length}, width:{width}")
    # punch_middle_point = [lp2[0]-t,lp2[1],lp2[2]] # changed from lp1 to lp2
    print(f"lp1:{lp1}, punch m p 1:{punch_middle_point}")
    punch_thickness = 10
    punch_width = length / 2 if length / 2 < 50 else 50

    pp1 = [punch_middle_point[0]- ((punch_width)),punch_middle_point[1],punch_middle_point[2]]
    pp2 = [pp1[0],pp1[1],pp1[2]+punch_thickness]
    pp3 = [pp2[0]+punch_width*2+t,pp2[1],pp2[2]]
    pp4 = [pp3[0],pp3[1],pp3[2]-punch_thickness]
    pp5 = [pp4[0]-((punch_width)),pp4[1],pp4[2]]
    pp6 = [pp5[0],pp5[1],pp5[2]-punch_thickness]
    
    pp7 = [pp6[0]-t,pp6[1],pp6[2]]
    pp8 = [pp7[0],pp7[1],pp7[2]+punch_thickness]
    
    punch1_points = [pp1,pp2,pp3,pp4,pp5,pp6,pp7,pp8]
    
    punch_middle_point = [lp1[0]+length,lp1[1],lp1[2]-width]  #bottom punch
    
    print(f"punch m p 2:{punch_middle_point}")

    pp1 = [punch_middle_point[0]- ((punch_width)),punch_middle_point[1],punch_middle_point[2]]
    pp2 = [pp1[0],pp1[1],pp1[2]-punch_thickness]
    pp3 = [pp2[0]+punch_width*2+t,pp2[1],pp2[2]]
    pp4 = [pp3[0],pp3[1],pp3[2]+punch_thickness]
    pp5 = [pp4[0]-((punch_width)),pp4[1],pp4[2]]
    pp6 = [pp5[0],pp5[1],pp5[2]+punch_thickness]
    
    pp7 = [pp6[0]-t,pp6[1],pp6[2]]
    pp8 = [pp7[0],pp7[1],pp7[2]-punch_thickness]

    punch2_points = [pp1,pp2,pp3,pp4,pp5,pp6,pp7,pp8]

    return punch1_points,punch2_points

def get_the_right_most_point(points):
    #point at largest x
    # point at largest y
    max_point = None
    largest_x = 0
    largest_y = 0 
    for p in points:
        if p[0]>largest_x and p[2]>largest_y:
            max_point = p 
            largest_x = p[0]
            largest_y = p[2]

    return max_point 

def get_outer_punches(outer_contour,length_line,width_line,t):
    '''
    This fn to calculate the outer punches points 
    it takes the outer_contour, length line, width line, and thickness as an input params

    '''
    
    #getting the points of the length
    l1 = [length_line[1],length_line[2],length_line[3]]
    l2 = [length_line[5],length_line[6],length_line[7]]
    

    #getting the points of the width, note that if the part is rectangular then its length and width are the same
    w1 = [width_line[1],width_line[2],width_line[3]]
    w2 = [width_line[5],width_line[6],width_line[7]]
    points = [l1,l2,w1,w2]


    length = get_dist(l1,l2)
    width = get_dist(w1,w2)

    pt = t
    pl = length + t
    pw = 20


    point = get_the_right_most_point(points)
    
    p1= point.copy()
    p2 = p1.copy()
    p2[0] -= pl/2
    p3 = p2.copy()
    p3[2]+=pw

    p8 = p1.copy()
    p8[2]-= (width/2)-5 # width over 2 


    p7 = p8.copy()
    p7[0]+=t
    p6 = p1.copy()
    p6[0]+=t
    
    p5 = p6.copy()
    p5[0]+=pl/2

    p4 = p5.copy()
    p4[2]+=pw

    punch1_points = [p1,p2,p3,p4,p5,p6,p7,p8]
    print("first punch points")
    for pp in punch1_points:

        print(pp)
    c1 =p1.copy()
    c1[2] = - c1[2]

    c2 =p2.copy()
    c2[2] = - c2[2]
    c3 =p3.copy()
    c3[2] = - c3[2]
    c4 =p4.copy()
    c4[2] = - c4[2]
    c5 =p5.copy()
    c5[2] = - c5[2]
    c6 =p6.copy()
    c6[2] = - c6[2]

    c7 =p7.copy()
    c7[2] = - c7[2]

    c8 =p8.copy()
    c8[2] = - c8[2]

    punch2_points = [c1,c2,c3,c4,c5,c6,c7,c8]
    print("first punch points after getting punch 2")
    for pp in punch1_points:

        print(pp)




    return punch1_points,punch2_points



################## strip layout functions

import math

import copy
def get_contour_points(contour):
    points = []
    for entity in contour:
        p1 = (entity[1],entity[2],entity[3])
        p2 = (entity[5],entity[6],entity[7])
        points.append(p1)
        points.append(p2)
    return points

def get_center_of_geometery(points):
    sum_x = 0
    sum_y = 0
    sum_z = 0
    m = len(points)
    for point in points:
        sum_x+=point[0]
        sum_y+=point[1]
        sum_z+=point[2]
        
    centroid = (sum_x/m,sum_y/m,sum_z/m)
    return centroid

def add_centroid(inner_contours):
    for contour in inner_contours:
        contour_points = get_contour_points(contour)
        contour_centroid = get_center_of_geometery(contour_points)
        for entity in contour:
            entity.append("centroid") 
            entity.append(contour_centroid)        
    return inner_contours

def calc_dist(p1,p2):
    d = math.sqrt((p1[0]-p2[0])**2+(p1[1]-p2[1])**2+(p1[2]-p2[2])**2)
    return d 


def far_point(contour):
    far_point = None
    far_dist = 0
    points = get_contour_points(contour)
    centroid = get_center_of_geometery(points)
    for p in points:
        d = math.sqrt((p[0]-centroid[0])**2+(p[1]-centroid[1])**2+(p[2]-centroid[2])**2)
        if far_dist<d:
            far_dist=d
            far_point=p

    return far_dist
    

def check_colliding_contours(contour1,contour2):
    constant = 25 #mm   
    e1  = contour1[0]
    e2 = contour2[0]
    if e1[8]=="LINE":
        c1 = e1[14]
    else:
        c1 = e1[18]
    
    f1 = far_point(contour1)
    l1 = f1 + constant
        
    if e2[8]=="LINE":
        c2 = e2[14]
    else:
        c2 = e2[18]
    
    f2 = far_point(contour2)
    l2 = f2 + constant

    d = calc_dist(c1,c2)
    
    if d> l1+l2:
        return False
    elif d<= l1+l2:
        return True
    
    

    
    
def get_groups(contour):
    if contour[0][8] =="LINE":
        g = contour[0][12]
    else:
        g = contour[0][16]

    return g

def get_contour_id(contour):
    if contour[0][8] =="LINE":
        c_id = contour[0][10]

    else:
        c_id = contour[0][14]
    
    return c_id
def create_initial_groups(inner_contours):
    for contour in inner_contours:
        for entity in contour:
            entity.append("g") 
            entity.append(1)        
    return inner_contours

def create_groups(inner_contours):

    idx=0
    while idx <=10:
        i=0
        ids = []
        for c1 in inner_contours:
            for c2 in [inner_contours[-i] for i in range(len(inner_contours))]:
                if c1 == c2:
                    continue
                # check if they are in the same group first 
                g1 = get_groups(c1)
                c_id1 = get_contour_id(c1)
                g2 = get_groups(c2)
                c_id2 = get_contour_id(c2)

                if c_id1 in ids or c_id2 in ids:
                    continue                 
                
                print(f"c1:{c_id1}, c2:{c_id2} - g1:{g1}, g2:{g2}")
                
                if g1 == g2:            
                    collide_check = check_colliding_contours(c1,c2)
                    if collide_check:
                        print("contours collides")
                        # choose between either contours to shift
                        # priority to circles to be at early stages
                        
                        if c1[0][8] == 'CIRCLE' and c2[0][8]!="CIRCLE":
                            #shift c2
                            for entity in c2: 
                                entity[12]+=1
                                ids.append(c_id2) 
                                
                        elif c1[0][8] != 'CIRCLE' and c2[0][8]=="CIRCLE":
                            #shift c1 
                            for entity in c1: 
                                entity[12]+=1 
                                ids.append(c_id1)
                        else:
                            #shift any contours 
                            for entity in c1: 
                                if entity[8] =="LINE":
                                    entity[12]+=1
                                    ids.append(c_id1)

                                else:
                                    entity[16]+=1 
                                    ids.append(c_id1)

        idx+=1
        
   

    return inner_contours

def get_width(outer_contours):
    for entity in outer_contours:
        p1 = (entity[1],entity[2],entity[3])
        p2 = (entity[5],entity[6],entity[7])
        dist = get_dist(p1,p2)
        entity.append("dist")
        entity.append(dist)

    width = 0 
    for contour in outer_contours:
        w = contour[10]
        if w > width:
            width = w 
        
    return width 
def get_total_groups(inner_contours):
    groups = set()
    for contour in inner_contours:
        g = get_groups(contour)
        groups.add(g)

    return groups
def get_contour_type(contour):
    if contour[0][8] == 'CIRCLE':
        return 'CIRCLE'
    else:
        return 'LINE'
def change_contour_group(ocontour,new_group):
    contour = copy.deepcopy(ocontour)
    if get_contour_type(contour) == "CIRCLE":
        for entity in contour:
            entity[16] = new_group
    else:
        for entity in contour:
            entity[12] = new_group
            
    return contour
        
def repeat_contours(inner_contours):
    #algorithm to repeat contours
    # get group 
    # loop from group to last group
    # add the contours to new contours list with current loop number as a group n 
    import copy 
    inner_contours1 = copy.deepcopy(inner_contours)

    #new contours list
    new_contours = []

    #get total no. of contours
    n_groups = len(get_total_groups(inner_contours1))

    # loop over contours
    for contour in inner_contours1:
        #get current contour group
        current_group = get_groups(contour)
        print(f"current groups:{current_group}")   
        for i in range(current_group,n_groups+2):
            new_contour = change_contour_group(contour,i)
            print(f"new contour group{get_groups(new_contour)}")
            new_contours.append(new_contour)
        
    return new_contours

def order_by_group(contours):
    contours_with_groups = [] 
    for contour in contours:
        g = get_groups(contour)
        contours_with_groups.append((contour,g))
    
    new_contours = sorted(contours_with_groups,key=lambda x: x[1])
    inner_contours_sorted = [] 
    for contour in new_contours:
        inner_contours_sorted.append(contour[0])
    return inner_contours_sorted    
# increase will be always in same dim. 
def adjust_contour_points(outer_contours,inner_contours):
    inner_contours = copy.deepcopy(inner_contours)
    groups = set()
    for contour in inner_contours:
        g = get_groups(contour)
        groups.add(g)
    
    thickness = 6
    delta_x = get_width(outer_contours) + thickness
    final_delta_width = delta_x * len(groups)
    print(f"before loop inner contours:{inner_contours}")
    for contour in inner_contours:
        print("-"*10)
        print("loop start")
        g  = get_groups(contour)
        print(f"loop g:{g} ")
        delta_x = (get_width(outer_contours) + thickness) * (g-1) 
        print(f"delta x:{delta_x}")
        for entity in contour:
            entity[1]+=delta_x 
            entity[5]+=delta_x 
            if entity[8]=='CIRCLE':
                entity[9]+=delta_x
                    
    print(f"after loop inner contours:{inner_contours}")

    if len(groups) ==1:
        final_delta_width=0
    else:
        final_delta_width -= get_width(outer_contours)
        
    print(f"final width:{final_delta_width}, delta x:{delta_x}, n groups:{len(groups)}")
    return inner_contours,final_delta_width

def transform_contours_to_original(inner_contours):
    contours = copy.deepcopy(inner_contours)
    new_contours = []
    for contour in contours:
        new_entities = []
        for entity in contour:
            if entity[8]=="LINE":
                entity= entity[:11]
                new_entities.append(entity)
            else:
                entity= entity[:15]
                new_entities.append(entity)

        new_contours.append(new_entities)
    return new_contours 

def find_lowest_x_points(points):
    # Initialize variables to store the lowest x-coordinates and corresponding points.
    lowest_x1 = float('inf')  # Initialize to positive infinity.
    lowest_x2 = float('inf')  # Initialize to positive infinity.
    point1 = None
    point2 = None
    
    # Loop through the points and update the lowest x-coordinates and corresponding points.
    for point in points:
        x = point[0]
        if x < lowest_x1:
            lowest_x2 = lowest_x1
            point2 = point1
            lowest_x1 = x
            point1 = point
        elif x < lowest_x2:
            lowest_x2 = x
            point2 = point
    
    return point1, point2

def find_highest_x_points(points):
    # Initialize variables to store the highest x-coordinates and corresponding points.
    highest_x1 = float('-inf')  # Initialize to negative infinity.
    highest_x2 = float('-inf')  # Initialize to negative infinity.
    point1 = None
    point2 = None
    
    # Loop through the points and update the highest x-coordinates and corresponding points.
    for point in points:
        x = point[0]
        if x > highest_x1:
            highest_x2 = highest_x1
            point2 = point1
            highest_x1 = x
            point1 = point
        elif x > highest_x2:
            highest_x2 = x
            point2 = point
    
    return [point1, point2]


def adjust_outer_contour(outer_contours,delta_x):
    delta_x= delta_x-6
    contour_points = set()
    for entity in outer_contours:
        p1 = (entity[1],entity[2],entity[3])
        p2 = (entity[5],entity[6],entity[7])
        contour_points.add(p1)
        contour_points.add(p2)
        
    print(f"contour points:")
    print(contour_points)
    
    ## get the two points at the right that will be changed 
    
    highest_points = find_highest_x_points(contour_points)
    print("-"*10)
    print(f"largest points:{highest_points}")

    width= get_width(outer_contours)
    new_contours = [] 
    for contour in outer_contours:
        p1 = (contour[1],contour[2],contour[3])
        p2 = (contour[5],contour[6],contour[7])
        if p1 in highest_points:
            contour[1]+=delta_x
        if p2 in highest_points:
            contour[5]+=delta_x
        new_contours.append(contour)
    
    return new_contours

## Fn to evaluate strip latout
def get_stage_number(n,n_max,n_min):
    fn = 100-90*((n-n_min)/(n_max-n_min))
    return fn


# to calculate strip stability factor
def calculate_contour_total_length(contour):
    # if contour is a circle then total length would be the perimeter of a circle 2 pi r or d*pi
    contour_type = get_contour_type(contour) 
    perimeter = 0

    if contour_type == 'CIRCLE':
        r = contour[0][12]
        perimeter = 2*math.pi*r 
    else:
        for entity in contour:
            p1,p2 = get_entity_points(entity)
            line_length = get_dist(p1,p2)
            perimeter +=line_length
    return perimeter


def process_strip_layout_contours(inner_contours,outer_contours):
    print("-"*10)
    print(f"inner contours before \n :{inner_contours}")
    print("-"*10)
    print(f"no of max contours = {len(inner_contours)}")
    n_max = len(inner_contours)
    
    inner_contours = create_initial_groups(inner_contours)
    inner_contours = add_centroid(inner_contours)
    inner_contours_m = create_groups(inner_contours)
    inner_contours_m2 = repeat_contours(inner_contours_m)
    inner_contours_m2 = order_by_group(inner_contours_m2)
    print(f"inner contours repeated "*5)
    print(inner_contours_m2)
    print(f"inner contours repeated "*5)

    contours_after,delta_x = adjust_contour_points(outer_contours,inner_contours_m2)
    processed_inner_contours = transform_contours_to_original(contours_after)
    processed_outer_contours= adjust_outer_contour(outer_contours,delta_x)
    
    print(f"processed:{contours_after}")
    # calculate the n stages
    n_min = len(get_total_groups(contours_after))

    print(f"min no of contours:{n_min}")
    
    
    ### calculating cut contour > make it as a function later
    outer_contour_copy = copy.deepcopy(outer_contours)
    #get width 
    length,length_entity,width,width_entity = get_length_width(outer_contour_copy)
    
    cut_contour =[]
    # get width entity and add delta_x - width to its x points
    t= 6
    width_delta = delta_x -t 
    width_entity[1] += width_delta
    width_entity[5] += width_delta 
    
    cut_contour.append(copy.deepcopy(width_entity))
    outer_contour_copy = copy.deepcopy(outer_contours)

    length,length_entity,width,width_entity = get_length_width(outer_contour_copy)

    width_delta = delta_x - 2*t 
    width_entity[1] += width_delta
    width_entity[5] += width_delta 
    
    cut_contour.append(copy.deepcopy(width_entity))
    
    
    ## horizontal lines
    length,length_entity,width,width_entity = get_length_width(outer_contour_copy)
    new_entity = copy.deepcopy(cut_contour[0])
    
    # processing
    new_entity[5] = cut_contour[1][1]
    new_entity[7] = cut_contour[1][3]


    # adding to contour
    cut_contour.append(copy.deepcopy(new_entity))
    
    ## horizontal line two 
    length,length_entity,width,width_entity = get_length_width(outer_contour_copy)
    new_entity = copy.deepcopy(cut_contour[0])
    print(length)
    # processing
    new_entity[5] = cut_contour[1][1]
    new_entity[7] = cut_contour[1][3]
    
    new_entity[3] += width
    new_entity[7] += width

    # adding to contour
    cut_contour.append(copy.deepcopy(new_entity))



    processed_inner_contours.append(cut_contour)
    
    # fn = get_stage_number(n_min,n_max,n_min)
    
    print("-"*10)
    print(f"inner contours after \n :{processed_inner_contours}")
    print("-"*10)

    # print(f"stage number factor:{fn}")
    return processed_inner_contours,processed_outer_contours




############################ feature

