from django.shortcuts import render, HttpResponse
from django.http import JsonResponse
from .step_processing import *
import pandas as pd

# forms.py
from django import forms


class FileUploadForm(forms.Form):
    file = forms.FileField()


# Create your views here.
def home(request):
    return HttpResponse("Welcome to STEP File API")


# views.py
from django.shortcuts import render
inner_contours_data =[]

def upload_file(request):
    if request.method == "POST":
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = request.FILES["file"]
            # Process or save the file as needed
            with open("file.step", "wb+") as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            return render(request, "success.html")
    else:
        print("form")
        form = FileUploadForm()
    return render(request, "upload.html", {"form": form})


def get_html_data(request):
    # the link will look like this http://localhost:8000/file-path/?path=D:\Abdalla Omar\repos\hussieny_work\final-data-extraction\punch sample 4.STEP
    # Assuming the file path is sent as a query parameter named 'path'
    file_path = "file.step"

    if file_path:
        # Process the file path or perform any desired operations
        # ...
        step_array = get_file_array(file_path)
        major_face = identify_major_face(step_array)
        output_array = get_extracted_data(step_array, [major_face])
        outer_boundary = get_specific_element(output_array, "FACE_OUTER_BOUND")
        outer_boundary_data = get_extracted_data(step_array, outer_boundary)
        edge_curve_outer_bond_data = get_specific_element(
            outer_boundary_data, "EDGE_CURVE"
        )
        outer_contour_data = extract_outer_face_data(step_array, major_face)
        inner_boundaries = get_specific_element(output_array, "FACE_BOUND")
        print(inner_boundaries)
        inner_contours_data = []

        for i,contour in enumerate(inner_boundaries):
            print(f"contour:{contour}")
            contour_data = extract_inner_face_data(step_array, contour,i)

            if contour_data[0][8] == "CIRCLE":
                df = pd.DataFrame(contour_data)
                df_without_duplication = df.drop_duplicates(subset=[8, 9, 10, 11, 12])

                contour_data = df_without_duplication.to_numpy()

            print(contour_data)
            inner_contours_data.append(contour_data)

        # print(inner_contours_data)
        context = {
            "outer_contour_data": outer_contour_data,
            "inner_contours_data": inner_contours_data,
        }
        return render(request, "data.html", context)


def get_file_path(request):
    global inner_contours_data
    # the link will look like this http://localhost:8000/file-path/?path=D:\Abdalla Omar\repos\hussieny_work\django-python-api\file.step
    # Assuming the file path is sent as a query parameter named 'path'
    print("-" * 100)
    file_path = request.GET.get("path", None)
    print(file_path)
    if file_path:
        # Process the file path or perform any desired operations
        # ...
        step_array = get_file_array(file_path)
        major_face = identify_major_face(step_array)
        output_array = get_extracted_data(step_array, [major_face])
        outer_boundary = get_specific_element(output_array, "FACE_OUTER_BOUND")
        outer_boundary_data = get_extracted_data(step_array, outer_boundary)
        edge_curve_outer_bond_data = get_specific_element(
            outer_boundary_data, "EDGE_CURVE"
        )
        global outer_contour_data

        outer_contour_data = extract_outer_face_data(step_array, major_face)
        inner_boundaries = get_specific_element(output_array, "FACE_BOUND")
        print(inner_boundaries)
        inner_contours_data = []

        for i,contour in enumerate(inner_boundaries):
            print(f"contour:{contour}")
            contour_data = extract_inner_face_data(step_array, contour,i)

            if contour_data[0][8] == "CIRCLE":
                print("circle")
                df = pd.DataFrame(contour_data)
                df_without_duplication = df.drop_duplicates(subset=[8, 9, 10, 11, 12])

                contour_data = df_without_duplication.values.tolist()

            print(contour_data)
            inner_contours_data.append(contour_data)

        return JsonResponse(
            {
                "outer contour data": list(outer_contour_data),
                "inner_contours_data": list(inner_contours_data),
            }
        )
    else:
        return JsonResponse({"error": "File path not provided"}, status=400)


def get_outer_contour(request):
    return HttpResponse("(40,10,20)")


def get_face_bound(request):
    return HttpResponse("circle,(40,10,20),5")



def get_punch_data(request):
    #this to draw inner circular punches only
    global inner_contours_data
    global outer_contour_data
    punches_contours = process_punch_data(inner_contours_data,outer_contour_data)
    
    return JsonResponse({"Punches contours": list(punches_contours)})

def get_rect_punch_data(request):
    global inner_contours_data
    global outer_contour_data
    punches_contours = process_rect_punch_data(inner_contours_data,outer_contour_data)

    return JsonResponse({"Punches contours":list(punches_contours)})


def get_extrude_punches(request):
    global inner_contours_data
    global outer_contour_data
    punches_contours = process_extrude_punches(inner_contours_data,outer_contour_data)
    
    return JsonResponse({"Punches contours": list(punches_contours)})


def get_die_data(request):
    global inner_contours_data
    die_contours = process_die_data(inner_contours_data)
    
    return JsonResponse({"Dies contours": list(die_contours)})

def get_irregular_die_data(request):
    global inner_contours_data
    die_contours = process_irregular_die_data(inner_contours_data)
    
    return JsonResponse({"Dies contours": list(die_contours)})

def get_circle_data(request):
    global inner_contours_data
    centerpoint = get_cirle_center(inner_contours_data)
    
    return JsonResponse({"centerpoint": list(centerpoint)})



def get_striplayout_data(request):
    #this to draw inner circular punches only
    global inner_contours_data
    global outer_contour_data
    processed_inner_contours,processed_outer_contours = process_strip_layout_contours(inner_contours_data,outer_contour_data)
    
    return JsonResponse(
        {
            "outer contour data": list(processed_outer_contours),
            "inner_contours_data": list(processed_inner_contours),
        }
    )
