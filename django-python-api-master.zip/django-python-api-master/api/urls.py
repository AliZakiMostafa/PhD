"""
URL configuration for step_api project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    # path("", views.home),
    path("outer-contour", views.get_outer_contour, name="outer-contour"),
    path("face-bound", views.get_face_bound, name="face-bound"),
    # path("file-path/", views.get_file_path, name="get_file_path"),
    path("file-path/", views.get_file_path, name="get_file_path"),
    path("get-step-data/", views.get_html_data, name="get_step_data"),
    
    path("punch/", views.get_punch_data, name="punch"), # this to process inner circular punches
    path("rect_punch/", views.get_rect_punch_data, name="rect_punch"), # this to process inner circular punches
    path("expunch/", views.get_extrude_punches, name="expunch"),

    path("die/", views.get_die_data, name="die"),
    path("irdie/", views.get_irregular_die_data, name="irdie"),

    path("centerpoint/", views.get_circle_data, name="centerpoint"),

    path('', views.upload_file, name='upload'),
    path("strip-layout/", views.get_striplayout_data, name="get_strip_layout"),
]
