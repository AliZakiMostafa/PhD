1. (3/9/2023) dies assembly was inverted so i put - in their x values while sketching, to invert them again.
2. (8.10.2023) dies are not assembled in their place for some parts but others are placed good. still working on the reason
3. (8.10.2023) striplayout drawn successfully but the width is not correct. 
4. (8.10.2023) inner entities grouped successfully but they are not drawn as their points states. 
5. (4.11.2023) cut punch is interfering with other punches and maybe need to put in consideration for one more stage.
