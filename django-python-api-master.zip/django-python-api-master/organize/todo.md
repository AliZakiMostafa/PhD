to do




doing
2. (23/9/2023) draw strip layout 






done
2. (3/9/2023) sovle misplaced dies in the assembly.  (done)
1. (3/9/2023) draw die for irregular inner punches. (doing)


