# This API to process STEP File data


# notes
1. slot feature is not applicable yet
2. if part has no inner contours it won't identify the major advanced face
3. today 30/9/2023 stopped before drawing strip layout after configuring the points 
4. 8/10/2023 strip layout is created successfully as a system but the dimensions need to be configured quite good.
