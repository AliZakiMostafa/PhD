# how to draw strip layout?

## idea 1 
1. get all punches points
2. check if their's collieding punches 
3. purpose a strip layout 
4. evaluate the strip layout
5. draw strip layout


## after finishing the strip layout i need to calculate factors to evaluate the strip layout

