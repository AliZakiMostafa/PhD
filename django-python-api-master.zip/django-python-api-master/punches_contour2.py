[
    [
        ['VERTEX_POINT', -18, 5, 38, 'VERTEX_POINT', -5, 5, 38, 'LINE', 'contour_id', 0],
        ['VERTEX_POINT', -5, 5, 38, 'VERTEX_POINT', -5, 5, 24, 'LINE', 'contour_id', 0],
        ['VERTEX_POINT', -5, 5, 24, 'VERTEX_POINT', -18, 5, 24, 'LINE', 'contour_id', 0],
        ['VERTEX_POINT', -18, 5, 24, 'VERTEX_POINT', -18, 5, 38, 'LINE', 'contour_id', 0]
    ],
    [
        ['VERTEX_POINT', -51, 5, 0, 'VERTEX_POINT', -41, 5, 0, 'LINE', 'contour_id', 1],
        ['VERTEX_POINT', -41, 5, 0, 'VERTEX_POINT', -41, 5, -6, 'LINE', 'contour_id', 1],
        ['VERTEX_POINT', -41, 5, -6, 'VERTEX_POINT', -51, 5, -6, 'LINE', 'contour_id', 1],
        ['VERTEX_POINT', -51, 5, -6, 'VERTEX_POINT', -51, 5, 0, 'LINE', 'contour_id', 1]
        ]
    ]